﻿using Newtonsoft.Json;
public class Connection
{
    public static readonly string EndpointUri = "https://mobileapp1.documents.azure.com:443/";
    public static readonly string PrimaryKey = "PFFbffhTkiBcJks6b77kFvgLYgrswoNzRVj89OXcZFwcNn0NpShL26iGfp8lDkpoVyaC7Fwos6CIwn18TQAfFA==";
    public static readonly string DatabaseName = "Pizzaria";
    public static readonly string CollectionName = "Pizza";
}