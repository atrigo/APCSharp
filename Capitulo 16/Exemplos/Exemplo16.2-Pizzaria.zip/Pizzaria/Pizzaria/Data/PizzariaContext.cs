﻿using Microsoft.EntityFrameworkCore;
using Pizzaria.Models;

namespace Pizzaria.Data
{
    public class PizzariaContext : DbContext
    {
        public PizzariaContext(DbContextOptions<PizzariaContext> options): base(options)
        {
        }

        public DbSet<Pizza> Pizza { get; set; }
    }
}
