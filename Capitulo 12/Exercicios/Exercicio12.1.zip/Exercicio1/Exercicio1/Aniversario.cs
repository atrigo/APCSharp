﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio1
{
    public class Aniversario
    {
        public string Nome { get; set; }
        public DateTime DataDeNascimento { get; set; }

        public Aniversario(string nome, DateTime dataDeNascimento)
        {
            Nome = nome;
            DataDeNascimento = dataDeNascimento;
        }
    }
}
