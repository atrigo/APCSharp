﻿using System;
using System.Collections.Generic;

namespace Exercicio1
{
    class Program
    {
        static void CriarAniversario(List<Aniversario> lst)
        {
            Console.WriteLine("Adicionar aniversariante");
            Console.Write("Nome: ");
            string nome = Console.ReadLine();
            Console.Write("Data de aniversário (no formato dd/mm/yyyy): ");
            string strData = Console.ReadLine();
            string[] parametros = strData.Split('/');
            int dia = Convert.ToInt32(parametros[0]);
            int mes = Convert.ToInt32(parametros[1]);
            int ano = Convert.ToInt32(parametros[2]);
            lst.Add(new Aniversario(nome, new DateTime(ano, mes, dia)));
        }

        static void ListarAniversarios(List<Aniversario> lst)
        {
            Console.WriteLine("Lista de aniversários: ");
            foreach (Aniversario a in lst)
            {
                Console.Write("Nome: {0} Data de aniversário: {1}", a.Nome, a.DataDeNascimento.ToShortDateString());
            }
            Console.WriteLine();
        }

        static void PesquisarAniversario(List<Aniversario> lst)
        {
            Console.Write("Indique os nomes do ano com um inteiro (1-janeiro,...,12-dezembro): ");
            int mes = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Lista de aniversários do mês {0}", mes);
            foreach (Aniversario a in lst)
            {
                if (a.DataDeNascimento.Month == mes)
                    Console.Write("Nome: {0} Data de aniversário: {1}", a.Nome, a.DataDeNascimento.ToShortDateString());
            }
            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            List<Aniversario> lstAniversarios = new List<Aniversario>();
            int opcao = 0;
            do
            {
                Console.WriteLine("Aplicação dos aniversários:\n1-Inserir aniversário.\n2-Listar aniversários.\n3-Pesquisar aniversários por mês.\n0-Sair.");
                opcao = Convert.ToInt32(Console.ReadLine());
                switch (opcao)
                {
                    case 1:
                        CriarAniversario(lstAniversarios);
                        break;
                    case 2:
                        ListarAniversarios(lstAniversarios);
                        break;
                    case 3:
                        PesquisarAniversario(lstAniversarios);
                        break;
                    default:
                        Console.WriteLine("Opção inválida");
                        break;
                }
            } while (opcao != 0);
        }
    }
}
