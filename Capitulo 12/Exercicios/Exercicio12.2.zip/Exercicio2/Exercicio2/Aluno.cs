﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio2
{
    class Aluno: IComparable<Aluno>
    {
        //Neste caso utilizaram-se atributos, mas também se poderiam utilizar propriedades
        int numAluno;
        string nome;
        int idade;
        double altura;

        public double getAltura() {
            return this.altura;
        }

        public int getIdade() {
            return this.idade;
        }

        public Aluno(int numero, string nome, int idade, double altura) {
            this.numAluno = numero;
            this.nome = nome;
            this.idade = idade;
            this.altura = altura;
        }

        public override string ToString()
        {
            return "Numero do aluno: " + this.numAluno + " Nome: "+ this.nome + 
                " Idade: "+ this.idade +" Altura: "+ this.altura;
        }

        public int CompareTo(Aluno a) {
            return this.nome.CompareTo(a.nome);
        }
    }
}
