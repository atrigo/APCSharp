﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio2
{
    class Turma
    {
        //Neste caso utilizaram-se propriedades, mas também se poderiam ter utilizado atributos e
        //os respetivo métodos
        public string Disciplina { get; set; }

        public List<Aluno> lstAlunos { get; set; }
        
    }
}
