﻿using System;
using System.Collections.Generic;


namespace Exercicio2
{
    class Program
    {


        /*
         * Na classe Program crie um método para mostrar todos os alunos de uma turma.
         * Na classe Program crie um método que apresente os alunos ordenados alfabeticamente pelo nome.
         * Na classe Program crie um método que apresente os alunos ordenados pela idade.
         * Na classe Program crie um método que devolva a altura média dos alunos de uma turma.
         * No método principal da classe Program:
         * Crie três alunos, a1, a2 e a3 e adicione-os à turma t1 de música.
         * Apresente os alunos da turma t1 ordenados alfabeticamente pelo nome.
         * Apresente os alunos da turma t1 ordenados pela idade.
         * Crie uma turma t2 de matemática por cópia da turma t1 e remova o aluno a2 pois não faz parte desta turma.
         * Apresente as alturas médias das turmas t1 e t2.
        */

        static void ApresentaAlunos(Turma t) {
            Console.WriteLine("Alunos da turma de {0}", t.Disciplina);
            foreach (Aluno a in t.lstAlunos)
                Console.WriteLine(a.ToString());
        }
        static void ApresentaAlunosOrdenadosAlfabeticamente(Turma t)
        {
            Console.WriteLine("Alunos ordenados alfabeticamente",t.Disciplina);
            t.lstAlunos.Sort();
            ApresentaAlunos(t);
        }

        public class CompararPorIdade : IComparer<Aluno> { 
            public int Compare(Aluno a1, Aluno a2)
            {
                return a1.getIdade().CompareTo(a2.getIdade());
            }
        }
        static void ApresentaAlunosOrdenadosPelaIdade(Turma t)
        {
            Console.WriteLine("Alunos ordenados pela idade");
            CompararPorIdade porIdade = new CompararPorIdade();
            t.lstAlunos.Sort(porIdade);
            ApresentaAlunos(t);
        }

        static double AlturaMedia(Turma t)
        {
            double soma = 0;
            foreach (Aluno a in t.lstAlunos)
                soma += a.getAltura();
            return soma/t.lstAlunos.Count;
        }


        static void Main(string[] args)
        {
            Turma t1 = new Turma();
            t1.Disciplina = "Musica";
            Aluno a1 = new Aluno(1,"Antonio",23,1.78);
            Aluno a2 = new Aluno(2,"Joana",17,1.60);
            Aluno a3 = new Aluno(3,"Jose",25,1.90);
            t1.lstAlunos = new List<Aluno>();
            t1.lstAlunos.Add(a1);
            t1.lstAlunos.Add(a2);
            t1.lstAlunos.Add(a3);
            ApresentaAlunos(t1);
            ApresentaAlunosOrdenadosAlfabeticamente(t1);
            ApresentaAlunosOrdenadosPelaIdade(t1);
            Turma t2 = new Turma();
            t2.Disciplina = "Matematica";
            t2.lstAlunos = new List<Aluno>(t1.lstAlunos);
            t2.lstAlunos.Remove(a2);
            ApresentaAlunos(t2);
            Console.WriteLine("A media dos alunos da turma de {1} é: {0:F2}", AlturaMedia(t1),t1.Disciplina);
            Console.WriteLine("A media dos alunos da turma de {1} é: {0:F2}", AlturaMedia(t2),t2.Disciplina);
        }
    }
}
