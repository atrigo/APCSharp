﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio3
{
    class Contacto
    {
        public string Nome { get; set; }
        public string Rede { get; set; } //Vodafone, MEO, NOS
        public int Telefone { get; set; }
    }
}
