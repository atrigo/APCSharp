﻿using System;
using System.Collections.Generic;

namespace Exercicio3
{
    class Program
    {

        /*
         * Declare uma classe Contacto com os seguintes atributos nome, rede e número de telefone;
         * Utilizando a classe List para guardar a lista de contactos, crie e teste os métodos necessários às seguintes operações:
         * Guardar os dados de um contacto.
         * Mostrar os dados de um contacto.
         * Percorrer a lista de contactos.
         * Pesquisar os contactos de uma determinada rede.
         * Pesquisar o número de telefone de um determinado contacto.
         * Pesquisar o nome do contacto com um determinado número de telefone.
         * Remover da agenda um contacto pelo número de telefone.
        */

        static void Adicionar(List<Contacto> lst) {
            Console.Write("Nome: ");
            string nome = Console.ReadLine();
            Console.Write("Rede: ");
            string rede = Console.ReadLine();
            Console.Write("Numero: ");
            int numero = Convert.ToInt32(Console.ReadLine());
            Contacto c = new Contacto();
            c.Nome = nome;
            c.Rede = rede;
            c.Telefone = numero;
            lst.Add(c);
        }
        static void MostrarDados(Contacto c)
        {
            Console.WriteLine("Nome: {0} Rede: {1} Numero: {2}",c.Nome,c.Rede,c.Telefone);
        }

        static void MostrarListaDeContactos(List<Contacto> lst) {
            foreach (Contacto c in lst)
                MostrarDados(c);
        }

        static void PesquisarContactosDeUmaRede(List<Contacto> lst)
        {
            Console.Write("Indique a rede cujos contactos deseja visualizar: ");
            string rede = Console.ReadLine();
            foreach (Contacto c in lst)
                if (c.Rede==rede)
                    MostrarDados(c);
        }

        static void PesquisarContactosPorNome(List<Contacto> lst)
        {
            Console.Write("Indique o nome do contacto: ");
            string nome = Console.ReadLine();
            foreach (Contacto c in lst)
                if (c.Nome == nome)
                    MostrarDados(c);
        }

        static void PesquisarContactosPorTelefone(List<Contacto> lst)
        {
            Console.Write("Indique o telefone do contacto: ");
            int numero = Convert.ToInt32(Console.ReadLine());
            foreach (Contacto c in lst)
                if (c.Telefone == numero)
                    MostrarDados(c);
        }

        static void RemoverContactoPorTelefone(List<Contacto> lst)
        {
            Console.Write("Indique o telefone do contacto: ");
            int numero = Convert.ToInt32(Console.ReadLine());
            int pos = -1;
            for (int i = 0; i < lst.Count; i++)
                if (lst[i].Telefone == numero)
                    pos = i;
            if (pos != -1)
                lst.RemoveAt(pos);
        }

        static void Main(string[] args)
        {
            List<Contacto> lstContactos = new List<Contacto>();
            int opcao = 0;
            do
            {
                Console.WriteLine("1 - Adicionar um contacto.");
                Console.WriteLine("2 - Percorrer a lista de contactos.");
                Console.WriteLine("3 - Pesquisar os contactos de uma determinada rede.");
                Console.WriteLine("4 - Pesquisar o número de telefone de um determinado contacto.");
                Console.WriteLine("5 - Pesquisar o nome do contacto com um determinado número de telefone.");
                Console.WriteLine("6 - Remover da agenda um contacto pelo número de telefone.");
                Console.WriteLine("0 - Sair.");

                opcao = Convert.ToInt32(Console.ReadLine());

                switch (opcao) {
                    case 0:
                        break;
                    case 1:
                        Adicionar(lstContactos);
                        break;
                    case 2:
                        MostrarListaDeContactos(lstContactos);
                        break;
                    case 3:
                        PesquisarContactosDeUmaRede(lstContactos);
                        break;
                    case 4:
                        PesquisarContactosPorNome(lstContactos);
                        break;
                    case 5:
                        PesquisarContactosPorTelefone(lstContactos);
                        break;
                    case 6:
                        RemoverContactoPorTelefone(lstContactos);
                        break;
                    default:
                        Console.WriteLine("Opção inválida!");
                        break;
                }
            } while (opcao != 0);
        }
    }
}
