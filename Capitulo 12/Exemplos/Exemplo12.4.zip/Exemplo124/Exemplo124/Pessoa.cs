﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemplo124
{
    public class Pessoa
    {
        //Atributos tornados publicos para serem acessiveis pelas
        //classes de comparacao
        public string nome;
        public int idade;
        public Pessoa(string nome, int idade)
        {
            this.nome = nome;
            this.idade = idade;
        }
        override
        public string ToString()
        {
            return "Nome: " + nome + " Idade: " + idade;
        }
    }
}
