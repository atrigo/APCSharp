﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemplo124
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Pessoa> pessoas = new List<Pessoa>();
            pessoas.Add(new Pessoa("Matilde", 20));
            pessoas.Add(new Pessoa("Helena", 30));
            pessoas.Add(new Pessoa("Jorge", 40));
            pessoas.Add(new Pessoa("Andre", 10));
            ComparaPessoaPorNome porNome = new ComparaPessoaPorNome();
            ComparaPessoaPorIdade porIdade = new ComparaPessoaPorIdade();
            pessoas.Sort(porNome);
            foreach (Pessoa p in pessoas)
                Console.WriteLine(p);
            pessoas.Sort(porIdade);
            foreach (Pessoa p in pessoas)
                Console.WriteLine(p);
        }
    }
}
