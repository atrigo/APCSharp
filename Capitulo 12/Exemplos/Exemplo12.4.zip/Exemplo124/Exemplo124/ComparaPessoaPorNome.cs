﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemplo124
{
    public class ComparaPessoaPorNome : IComparer<Pessoa>
    {
        public int Compare(Pessoa p1, Pessoa p2)
        {
            return p1.nome.CompareTo(p2.nome);
        }
    }
}
