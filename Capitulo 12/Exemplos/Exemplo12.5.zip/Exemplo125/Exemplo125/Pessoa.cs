﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemplo125
{
    public class Pessoa : IComparable<Pessoa>
    {
        string nome;
        //Tornou-se este atributo publico para poder ser acedido
        //pelo comparador
        public int idade;
        public Pessoa(string nome, int idade)
        {
            this.nome = nome;
            this.idade = idade;
        }
        override
        public string ToString()
        {
            return "Nome: " + nome + " Idade: " + idade;
        }
        //Metodo CompareTo para comparar a classe pelo atributo nome
        public int CompareTo(Pessoa p)
        {
            return this.nome.CompareTo(p.nome);
        }
    }
}
