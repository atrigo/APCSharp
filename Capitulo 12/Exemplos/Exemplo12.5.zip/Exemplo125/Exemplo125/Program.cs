﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemplo125
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Pessoa> pessoas = new List<Pessoa>();
            pessoas.Add(new Pessoa("Matilde", 20));
            pessoas.Add(new Pessoa("Helena", 30));
            pessoas.Add(new Pessoa("Jorge", 40));
            pessoas.Add(new Pessoa("Andre", 10));
            //Ordena pelo nome, como definido no metodo CompareTo
            Console.WriteLine("Ordena pelo nome:");
            pessoas.Sort();
            foreach (Pessoa p in pessoas)
                Console.WriteLine(p);
            //Ordena pela idade, passando para o Sort o método de ordenação
            Console.WriteLine("Ordena pelo idade, passando o método:");
            pessoas.Sort(delegate (Pessoa p1, Pessoa p2) {
                return p1.idade.CompareTo(p2.idade);
            });
            foreach (Pessoa p in pessoas)
                Console.WriteLine(p);

        }
    }
}
