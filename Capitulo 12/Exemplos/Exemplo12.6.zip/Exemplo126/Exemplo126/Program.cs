﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemplo126
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<String, Pessoa> pessoas = new Dictionary<String, Pessoa>();
            pessoas.Add("A", new Pessoa("Matilde", 20));
            pessoas.Add("B", new Pessoa("Helena", 30));
            pessoas.Add("C", new Pessoa("Jorge", 40));
            pessoas.Add("D", new Pessoa("Andre", 10));

            //Mostra a pessoa que tema chave "A"
            Console.WriteLine(pessoas["A"]);
            //Para ler os elementos do dicionario e necessario utilizar KeyValuePair
            foreach (KeyValuePair<string, Pessoa> p in pessoas)
                Console.WriteLine("Chave = {0}, Valor = {1}", p.Key, p.Value);
            //Remover um elemento
            pessoas.Remove("C");
            foreach (KeyValuePair<string, Pessoa> p in pessoas)
                Console.WriteLine("Chave = {0}, Valor = {1}", p.Key, p.Value);
        }
    }
}
