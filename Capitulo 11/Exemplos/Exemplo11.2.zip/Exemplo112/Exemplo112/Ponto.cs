﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemplo112
{
    class Ponto
    {
        int x;
        int y;
        public Ponto(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        public override bool Equals(Object obj)
        {
            //Verificar se o objeto existe e se sao do mesmo tipo
            if ((obj == null) || !this.GetType().Equals(obj.GetType()))
            {
                return false;
            }
            else
            {
                Ponto p = (Ponto)obj;
                return (x == p.x) && (y == p.y);
            }
        }


    }
}
