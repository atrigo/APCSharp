﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemplo112
{
    class Program
    {
        static void Main(string[] args)
        {
            Ponto p1 = new Ponto(2, 1);
            Ponto p2 = new Ponto(2, 1);
            Ponto p3 = new Ponto(2, 2);
            Console.WriteLine(p1 == p2);
            Console.WriteLine(p1.Equals(p2));
            Console.WriteLine(p1.Equals(p3));
        }
    }
}
