﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemplo113
{
    class Coordenadas
    {
        public double x;
        public double y;

        public Coordenadas()
        {
        }

        public Coordenadas(double x, double y)
        {
            this.x = x;
            this.y = y;
        }
    }
}
