﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemplo113
{
    class Program
    {
        static void Main(string[] args)
        {
            Coordenadas p1 = new Coordenadas(1, 2);
            Coordenadas p2 = new Coordenadas();
            
            p2.x = 3;
            p2.y = 2;

            double distanciaEuclidiana = Math.Sqrt(Math.Pow((p1.x - p2.x), 2) + Math.Pow((p1.y - p2.y), 2));
            Console.WriteLine(distanciaEuclidiana);
        }
    }
}
