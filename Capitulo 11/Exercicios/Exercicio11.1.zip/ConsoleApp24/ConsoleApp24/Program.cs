﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp24
{
    class Program
    {
        static void Main(string[] args)
        {
            Aluno a1 = new Aluno("Antonio", 18);
            Aluno a2 = new Aluno("Miguel", 21);
            Aluno a3 = new Aluno("Joao", 19);

            Console.WriteLine("{0}",
                (a1.GetIdade() + a2.GetIdade() + a3.GetIdade()) / 3);
        }
    }
}
