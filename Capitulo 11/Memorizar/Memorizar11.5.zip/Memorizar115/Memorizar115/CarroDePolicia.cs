﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memorizar115
{
    class CarroDePolicia : Carro
    {
        bool sirene;
        public string EstadoDaSirene()
        {
            if (sirene)
                return "Sirene ligada!";
            else
                return "Sirene desligada!";
        }

        public CarroDePolicia(int posX, int posY)
            : base("Policia", posX, posY, 1)
        {
            sirene = false;
        }
        public void LigarSirene()
        {
            sirene = true;
        }
        public void DesligarSirene()
        {
            sirene = false;
        }

        public override string DevolverTipo()
        {
            return "Carro da policia.";
        }
    }
}
