﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memorizar115
{
    class CarroDescapotavel: Carro
    {
        public CarroDescapotavel(string nome, int posX, int posY, int cor)
            : base(nome, posX, posY, cor)
        {
        }

        public override string DevolverTipo()
        {
            return "Carro descapotavel.";
        }
    }
}
