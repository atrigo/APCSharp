﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memorizar115
{
    class Program
    {
        static void Main(string[] args)
        {
            Carro a = new Carro("Mini Cooper", 1, 2, 1);
            CarroDePolicia b = new CarroDePolicia(1, 1);
            CarroDescapotavel c = new CarroDescapotavel("Mazda MX5", 2, 3, 1);
            MostrarTipoDeCarro(a);
            MostrarTipoDeCarro(b);
            MostrarTipoDeCarro(c);
        }

        static void MostrarTipoDeCarro(Carro carro)
        {
            Console.WriteLine("{0}", carro.DevolverTipo());
        }
    }
}
