﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memorizar113
{
    class Pessoa
    {
        //Os atributos foram declarados publicos para facilitar
        //o acesso aos mesmos neste exemplo
        public string nome;
        public CartaoDeCidadao cc;
        public Pessoa(string nome, int numeroDeContribuinte)
        {
            this.nome = nome;
            cc = new CartaoDeCidadao(numeroDeContribuinte);
        }
        public Pessoa ShallowCopy()
        {
            return (Pessoa)this.MemberwiseClone();
        }
        public Pessoa DeepCopy()
        {
            Pessoa p = (Pessoa)this.MemberwiseClone();
            p.cc = new CartaoDeCidadao(cc.numeroDeContribuinte);
            p.nome = String.Copy(nome);
            return p;
        }
    }
}
