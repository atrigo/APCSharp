﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memorizar113
{
    class CartaoDeCidadao
    {
        //O atributo foi declarado publico para facilitar
        //o acesso ao mesmo neste exemplo
        public int numeroDeContribuinte;
        public CartaoDeCidadao(int numeroDeContribuinte)
        {
            this.numeroDeContribuinte = numeroDeContribuinte;
        }
    }
}
