﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memorizar113
{
    class Program
    {
        static void Main(string[] args)
        {
            Pessoa p1 = new Pessoa("Helena", 111111111);
            Pessoa p2 = p1.ShallowCopy();
            Pessoa p3 = p1.DeepCopy();
            Console.WriteLine("P1 - Nome: " + p1.nome + " CC: " + p1.cc.numeroDeContribuinte);
            p2.nome = "Andre";
            p2.cc.numeroDeContribuinte = 222222222;
            Console.WriteLine("P1 - Nome: " + p1.nome + " CC: " + p1.cc.numeroDeContribuinte);
            Console.WriteLine("P2 - Nome: " + p2.nome + " CC: " + p2.cc.numeroDeContribuinte);
            Console.WriteLine("P3 - Nome: " + p3.nome + " CC: " + p3.cc.numeroDeContribuinte);
            p3.nome = "Matilde";
            p3.cc.numeroDeContribuinte = 333333333;
            Console.WriteLine("P1 - Nome: " + p1.nome + " CC: " + p1.cc.numeroDeContribuinte);
            Console.WriteLine("P2 - Nome: " + p2.nome + " CC: " + p2.cc.numeroDeContribuinte);
            Console.WriteLine("P3 - Nome: " + p3.nome + " CC: " + p3.cc.numeroDeContribuinte);
        }
    }
}
