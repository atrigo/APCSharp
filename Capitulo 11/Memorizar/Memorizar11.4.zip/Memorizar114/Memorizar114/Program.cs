﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memorizar114
{
    class Program
    {
        static void Main(string[] args)
        {
            Carro a = new Carro("Mini Cooper", 1, 2, 0);
            //Carro da policia inicializado com posicao x = 1 e posicao y = 1 
            CarroDePolicia b = new CarroDePolicia(1, 1);
            //Metodo especifico da classe CarroPolicia
            Console.WriteLine(b.EstadoDaSirene());
            b.LigarSirene();
            Console.WriteLine(b.EstadoDaSirene());
            //Metodos da classe Carro
            b.MoverDireita();
            b.MostrarMovimento();
        }
    }
}
