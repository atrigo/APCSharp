﻿/*
 * Memorizar 11.2
 * Livro: Aprenda a programar com C#
 * Autores: Antonio Trigo e Jorge Henriques
 * Disponível em: http://www.silabo.pt
*/

using System;

namespace ConsoleApp11
{
    public class Aluno
    {
        static int ultimoNumeroDeAluno = 1;
        int numeroDeAluno;
        string nome;
        public Aluno(string nome)
        {
            this.nome = nome;
            this.numeroDeAluno = ultimoNumeroDeAluno;
            ultimoNumeroDeAluno++;
        }
        public void MostraDados()
        {
            Console.WriteLine("Nome: " + this.nome + " Numero: " + this.numeroDeAluno);
        }
    }
}