﻿/*
 * Memorizar 11.2
 * Livro: Aprenda a programar com C#
 * Autores: Antonio Trigo e Jorge Henriques
 * Disponível em: http://www.silabo.pt
*/

using System;

namespace ConsoleApp11
{
    class Program
    {
        static void Main(string[] args)
        {
            Aluno a1 = new Aluno("Miguel");
            Aluno a2 = new Aluno("Joana");
            a1.MostraDados();
            a2.MostraDados();
        }
    }
}