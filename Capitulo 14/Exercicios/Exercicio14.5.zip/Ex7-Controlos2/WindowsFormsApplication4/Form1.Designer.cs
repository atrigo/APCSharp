﻿namespace teste
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.checkedListBoxCostumaLer = new System.Windows.Forms.CheckedListBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.radioButtonCasado = new System.Windows.Forms.RadioButton();
            this.radioButtonSolteiro = new System.Windows.Forms.RadioButton();
            this.radioButtonViuvo = new System.Windows.Forms.RadioButton();
            this.radioButtonFeminino = new System.Windows.Forms.RadioButton();
            this.radioButtonMasculino = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxEC = new System.Windows.Forms.TextBox();
            this.groupBoxSexo = new System.Windows.Forms.GroupBox();
            this.textBoxSexo = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBoxNasc = new System.Windows.Forms.ComboBox();
            this.labelLocNasc = new System.Windows.Forms.Label();
            this.textBoxNasc = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxRes = new System.Windows.Forms.TextBox();
            this.listBoxRes = new System.Windows.Forms.ListBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.labelDNasc = new System.Windows.Forms.Label();
            this.textBoxDNasc = new System.Windows.Forms.TextBox();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.textBoxDInsc = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.listBoxLing = new System.Windows.Forms.ListBox();
            this.textBoxLing = new System.Windows.Forms.TextBox();
            this.groupBoxLing = new System.Windows.Forms.GroupBox();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.labelNLivros = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBoxSexo.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBoxLing.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // checkedListBoxCostumaLer
            // 
            this.checkedListBoxCostumaLer.AllowDrop = true;
            this.checkedListBoxCostumaLer.BackColor = System.Drawing.SystemColors.Info;
            this.checkedListBoxCostumaLer.CheckOnClick = true;
            this.checkedListBoxCostumaLer.FormattingEnabled = true;
            this.checkedListBoxCostumaLer.Items.AddRange(new object[] {
            "Revistas",
            "Jornais",
            "Banda Desenhada",
            "Teatro",
            "Romances",
            "Diários",
            "Policiais",
            "Poesia",
            "Biografias",
            "Livros Escolares"});
            this.checkedListBoxCostumaLer.Location = new System.Drawing.Point(20, 25);
            this.checkedListBoxCostumaLer.Name = "checkedListBoxCostumaLer";
            this.checkedListBoxCostumaLer.Size = new System.Drawing.Size(141, 214);
            this.checkedListBoxCostumaLer.TabIndex = 1;
            this.checkedListBoxCostumaLer.SelectedIndexChanged += new System.EventHandler(this.checkedListCostumaLer_SelectedIndexChanged);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Info;
            this.textBox1.Location = new System.Drawing.Point(677, 251);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(178, 78);
            this.textBox1.TabIndex = 2;
            // 
            // radioButtonCasado
            // 
            this.radioButtonCasado.AutoSize = true;
            this.radioButtonCasado.Location = new System.Drawing.Point(7, 20);
            this.radioButtonCasado.Name = "radioButtonCasado";
            this.radioButtonCasado.Size = new System.Drawing.Size(73, 24);
            this.radioButtonCasado.TabIndex = 3;
            this.radioButtonCasado.TabStop = true;
            this.radioButtonCasado.Text = "Casado";
            this.radioButtonCasado.UseVisualStyleBackColor = true;
            this.radioButtonCasado.CheckedChanged += new System.EventHandler(this.radioButtonEC_CheckedChanged);
            // 
            // radioButtonSolteiro
            // 
            this.radioButtonSolteiro.AutoSize = true;
            this.radioButtonSolteiro.Location = new System.Drawing.Point(7, 58);
            this.radioButtonSolteiro.Name = "radioButtonSolteiro";
            this.radioButtonSolteiro.Size = new System.Drawing.Size(76, 24);
            this.radioButtonSolteiro.TabIndex = 3;
            this.radioButtonSolteiro.TabStop = true;
            this.radioButtonSolteiro.Text = "Solteiro";
            this.radioButtonSolteiro.UseVisualStyleBackColor = true;
            this.radioButtonSolteiro.CheckedChanged += new System.EventHandler(this.radioButtonEC_CheckedChanged);
            // 
            // radioButtonViuvo
            // 
            this.radioButtonViuvo.AutoSize = true;
            this.radioButtonViuvo.Location = new System.Drawing.Point(7, 96);
            this.radioButtonViuvo.Name = "radioButtonViuvo";
            this.radioButtonViuvo.Size = new System.Drawing.Size(63, 24);
            this.radioButtonViuvo.TabIndex = 3;
            this.radioButtonViuvo.TabStop = true;
            this.radioButtonViuvo.Text = "Viúvo";
            this.radioButtonViuvo.UseVisualStyleBackColor = true;
            this.radioButtonViuvo.CheckedChanged += new System.EventHandler(this.radioButtonEC_CheckedChanged);
            // 
            // radioButtonFeminino
            // 
            this.radioButtonFeminino.AutoSize = true;
            this.radioButtonFeminino.Location = new System.Drawing.Point(15, 25);
            this.radioButtonFeminino.Name = "radioButtonFeminino";
            this.radioButtonFeminino.Size = new System.Drawing.Size(86, 24);
            this.radioButtonFeminino.TabIndex = 4;
            this.radioButtonFeminino.TabStop = true;
            this.radioButtonFeminino.Text = "Feminino";
            this.radioButtonFeminino.UseVisualStyleBackColor = true;
            this.radioButtonFeminino.CheckedChanged += new System.EventHandler(this.radioButtonFeminino_CheckedChanged);
            // 
            // radioButtonMasculino
            // 
            this.radioButtonMasculino.AutoSize = true;
            this.radioButtonMasculino.Location = new System.Drawing.Point(15, 65);
            this.radioButtonMasculino.Name = "radioButtonMasculino";
            this.radioButtonMasculino.Size = new System.Drawing.Size(91, 24);
            this.radioButtonMasculino.TabIndex = 5;
            this.radioButtonMasculino.TabStop = true;
            this.radioButtonMasculino.Text = "Masculino";
            this.radioButtonMasculino.UseVisualStyleBackColor = true;
            this.radioButtonMasculino.CheckedChanged += new System.EventHandler(this.radioButtonMasculino_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.groupBox1.BackgroundImage = global::WindowsFormsApplication4.Properties.Resources.livros;
            this.groupBox1.Controls.Add(this.textBoxEC);
            this.groupBox1.Controls.Add(this.radioButtonViuvo);
            this.groupBox1.Controls.Add(this.radioButtonSolteiro);
            this.groupBox1.Controls.Add(this.radioButtonCasado);
            this.groupBox1.Location = new System.Drawing.Point(499, 177);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(118, 153);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Estado Civil";
            // 
            // textBoxEC
            // 
            this.textBoxEC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.textBoxEC.Location = new System.Drawing.Point(0, 126);
            this.textBoxEC.Name = "textBoxEC";
            this.textBoxEC.Size = new System.Drawing.Size(118, 26);
            this.textBoxEC.TabIndex = 8;
            this.textBoxEC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBoxSexo
            // 
            this.groupBoxSexo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.groupBoxSexo.BackgroundImage = global::WindowsFormsApplication4.Properties.Resources.livros;
            this.groupBoxSexo.Controls.Add(this.radioButtonMasculino);
            this.groupBoxSexo.Controls.Add(this.radioButtonFeminino);
            this.groupBoxSexo.Location = new System.Drawing.Point(499, 10);
            this.groupBoxSexo.Name = "groupBoxSexo";
            this.groupBoxSexo.Size = new System.Drawing.Size(118, 121);
            this.groupBoxSexo.TabIndex = 7;
            this.groupBoxSexo.TabStop = false;
            this.groupBoxSexo.Text = "Sexo";
            // 
            // textBoxSexo
            // 
            this.textBoxSexo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.textBoxSexo.Location = new System.Drawing.Point(499, 105);
            this.textBoxSexo.Name = "textBoxSexo";
            this.textBoxSexo.Size = new System.Drawing.Size(118, 26);
            this.textBoxSexo.TabIndex = 8;
            this.textBoxSexo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox2
            // 
            this.groupBox2.BackgroundImage = global::WindowsFormsApplication4.Properties.Resources.livros;
            this.groupBox2.Controls.Add(this.checkedListBoxCostumaLer);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox2.Location = new System.Drawing.Point(677, 10);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(178, 303);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "O que Costuma ler?";
            // 
            // comboBoxNasc
            // 
            this.comboBoxNasc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.comboBoxNasc.FormattingEnabled = true;
            this.comboBoxNasc.Items.AddRange(new object[] {
            "Aveiro",
            "Beja",
            "Braga",
            "Bragança",
            "Castelo Branco",
            "Coimbra",
            "Évora",
            "Faro",
            "Guarda",
            "Leiria",
            "Lisboa",
            "Portalegre",
            "Porto",
            "Santarém",
            "Setúbal",
            "Viana do Castelo",
            "Vila Real",
            "Viseu"});
            this.comboBoxNasc.Location = new System.Drawing.Point(213, 12);
            this.comboBoxNasc.Name = "comboBoxNasc";
            this.comboBoxNasc.Size = new System.Drawing.Size(143, 28);
            this.comboBoxNasc.TabIndex = 10;
            this.comboBoxNasc.SelectedIndexChanged += new System.EventHandler(this.comboBoxNasc_SelectedIndexChanged);
            // 
            // labelLocNasc
            // 
            this.labelLocNasc.AutoSize = true;
            this.labelLocNasc.Location = new System.Drawing.Point(12, 20);
            this.labelLocNasc.Name = "labelLocNasc";
            this.labelLocNasc.Size = new System.Drawing.Size(195, 20);
            this.labelLocNasc.TabIndex = 11;
            this.labelLocNasc.Text = "Local de Nascimento (distrito)";
            // 
            // textBoxNasc
            // 
            this.textBoxNasc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.textBoxNasc.Location = new System.Drawing.Point(362, 12);
            this.textBoxNasc.Name = "textBoxNasc";
            this.textBoxNasc.Size = new System.Drawing.Size(126, 26);
            this.textBoxNasc.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "Local de Residência (distrito)";
            // 
            // textBoxRes
            // 
            this.textBoxRes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.textBoxRes.Location = new System.Drawing.Point(362, 61);
            this.textBoxRes.Name = "textBoxRes";
            this.textBoxRes.Size = new System.Drawing.Size(126, 26);
            this.textBoxRes.TabIndex = 12;
            // 
            // listBoxRes
            // 
            this.listBoxRes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.listBoxRes.FormattingEnabled = true;
            this.listBoxRes.ItemHeight = 20;
            this.listBoxRes.Items.AddRange(new object[] {
            "",
            "Aveiro",
            "Beja",
            "Braga",
            "Bragança",
            "Castelo Branco",
            "Coimbra",
            "Évora",
            "Faro",
            "Guarda",
            "Leiria",
            "Lisboa",
            "Portalegre",
            "Porto",
            "Santarém",
            "Setúbal",
            "Viana do Castelo",
            "Vila Real",
            "Viseu"});
            this.listBoxRes.Location = new System.Drawing.Point(213, 65);
            this.listBoxRes.Name = "listBoxRes";
            this.listBoxRes.Size = new System.Drawing.Size(142, 24);
            this.listBoxRes.TabIndex = 13;
            this.listBoxRes.SelectedIndexChanged += new System.EventHandler(this.listBoxRes_SelectedIndexChanged);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.dateTimePicker1.Location = new System.Drawing.Point(12, 139);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(191, 26);
            this.dateTimePicker1.TabIndex = 14;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // labelDNasc
            // 
            this.labelDNasc.AutoSize = true;
            this.labelDNasc.Location = new System.Drawing.Point(14, 116);
            this.labelDNasc.Name = "labelDNasc";
            this.labelDNasc.Size = new System.Drawing.Size(188, 20);
            this.labelDNasc.TabIndex = 15;
            this.labelDNasc.Text = "------ Data de Nascimento ------";
            // 
            // textBoxDNasc
            // 
            this.textBoxDNasc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.textBoxDNasc.Location = new System.Drawing.Point(12, 171);
            this.textBoxDNasc.Name = "textBoxDNasc";
            this.textBoxDNasc.Size = new System.Drawing.Size(190, 26);
            this.textBoxDNasc.TabIndex = 12;
            this.textBoxDNasc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.monthCalendar1.Location = new System.Drawing.Point(8, 28);
            this.monthCalendar1.MaxSelectionCount = 100;
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 16;
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);
            // 
            // textBoxDInsc
            // 
            this.textBoxDInsc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.textBoxDInsc.Location = new System.Drawing.Point(8, 189);
            this.textBoxDInsc.Name = "textBoxDInsc";
            this.textBoxDInsc.Size = new System.Drawing.Size(227, 26);
            this.textBoxDInsc.TabIndex = 12;
            this.textBoxDInsc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.monthCalendar1);
            this.groupBox3.Controls.Add(this.textBoxDInsc);
            this.groupBox3.Location = new System.Drawing.Point(228, 116);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(241, 221);
            this.groupBox3.TabIndex = 17;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Período de leitura do último livro";
            // 
            // listBoxLing
            // 
            this.listBoxLing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.listBoxLing.FormattingEnabled = true;
            this.listBoxLing.ItemHeight = 20;
            this.listBoxLing.Items.AddRange(new object[] {
            "Português",
            "Inglês",
            "Francês",
            "Espanhol",
            "Alemão",
            "Grego"});
            this.listBoxLing.Location = new System.Drawing.Point(6, 25);
            this.listBoxLing.Name = "listBoxLing";
            this.listBoxLing.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listBoxLing.Size = new System.Drawing.Size(178, 104);
            this.listBoxLing.TabIndex = 13;
            this.listBoxLing.SelectedIndexChanged += new System.EventHandler(this.listBoxLing_SelectedIndexChanged);
            // 
            // textBoxLing
            // 
            this.textBoxLing.BackColor = System.Drawing.SystemColors.Info;
            this.textBoxLing.Location = new System.Drawing.Point(6, 147);
            this.textBoxLing.Multiline = true;
            this.textBoxLing.Name = "textBoxLing";
            this.textBoxLing.Size = new System.Drawing.Size(178, 78);
            this.textBoxLing.TabIndex = 2;
            // 
            // groupBoxLing
            // 
            this.groupBoxLing.Controls.Add(this.listBoxLing);
            this.groupBoxLing.Controls.Add(this.textBoxLing);
            this.groupBoxLing.Location = new System.Drawing.Point(6, 230);
            this.groupBoxLing.Name = "groupBoxLing";
            this.groupBoxLing.Size = new System.Drawing.Size(200, 231);
            this.groupBoxLing.TabIndex = 18;
            this.groupBoxLing.TabStop = false;
            this.groupBoxLing.Text = " Línguas de leitura";
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(238, 374);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(599, 226);
            this.webBrowser1.TabIndex = 19;
            this.webBrowser1.Url = new System.Uri("https://www.spautores.pt/", System.UriKind.Absolute);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.BackColor = System.Drawing.SystemColors.Info;
            this.numericUpDown1.Location = new System.Drawing.Point(18, 524);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(100, 26);
            this.numericUpDown1.TabIndex = 20;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown1.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // labelNLivros
            // 
            this.labelNLivros.AutoSize = true;
            this.labelNLivros.Location = new System.Drawing.Point(17, 490);
            this.labelNLivros.Name = "labelNLivros";
            this.labelNLivros.Size = new System.Drawing.Size(101, 20);
            this.labelNLivros.TabIndex = 11;
            this.labelNLivros.Text = "Nº livros lidos ";
            // 
            // Form1
            // 
            this.AccessibleDescription = "Form utilizada para testar controlos básicos";
            this.AccessibleName = "Form de Teste";
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(168)))));
            this.BackgroundImage = global::WindowsFormsApplication4.Properties.Resources.livros;
            this.ClientSize = new System.Drawing.Size(867, 623);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.webBrowser1);
            this.Controls.Add(this.groupBoxLing);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.labelDNasc);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.listBoxRes);
            this.Controls.Add(this.textBoxRes);
            this.Controls.Add(this.labelNLivros);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxDNasc);
            this.Controls.Add(this.textBoxNasc);
            this.Controls.Add(this.labelLocNasc);
            this.Controls.Add(this.comboBoxNasc);
            this.Controls.Add(this.textBoxSexo);
            this.Controls.Add(this.groupBoxSexo);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.groupBox2);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Arial Narrow", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hábitos de Leitura";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBoxSexo.ResumeLayout(false);
            this.groupBoxSexo.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBoxLing.ResumeLayout(false);
            this.groupBoxLing.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox checkedListBoxCostumaLer;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.RadioButton radioButtonCasado;
        private System.Windows.Forms.RadioButton radioButtonSolteiro;
        private System.Windows.Forms.RadioButton radioButtonViuvo;
        private System.Windows.Forms.RadioButton radioButtonFeminino;
        private System.Windows.Forms.RadioButton radioButtonMasculino;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBoxSexo;
        private System.Windows.Forms.TextBox textBoxSexo;
        private System.Windows.Forms.TextBox textBoxEC;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBoxNasc;
        private System.Windows.Forms.Label labelLocNasc;
        private System.Windows.Forms.TextBox textBoxNasc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxRes;
        private System.Windows.Forms.ListBox listBoxRes;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label labelDNasc;
        private System.Windows.Forms.TextBox textBoxDNasc;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.TextBox textBoxDInsc;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListBox listBoxLing;
        private System.Windows.Forms.TextBox textBoxLing;
        private System.Windows.Forms.GroupBox groupBoxLing;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label labelNLivros;
    }
}

