﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace teste
{
    public partial class Form1 : Form
    {
        public Form1()
        {
           InitializeComponent();
        }

        private void checkedListCostumaLer_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Clear();
            foreach(string s in checkedListBoxCostumaLer.CheckedItems)
                textBox1.Text += s+" ";
        }

        private void radioButtonFeminino_CheckedChanged(object sender, EventArgs e)
        {
                textBoxSexo.Text = radioButtonFeminino.Text;
        }

        private void radioButtonMasculino_CheckedChanged(object sender, EventArgs e)
        {
                textBoxSexo.Text = radioButtonMasculino.Text;
        }

        void radioButtonEC_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            textBoxEC.Text = rb.Text;
        }

        private void comboBoxNasc_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBoxNasc.Text = comboBoxNasc.SelectedItem.ToString()+" ("+comboBoxNasc.SelectedIndex.ToString()+")";
        }

        private void listBoxRes_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBoxRes.Text = listBoxRes.SelectedItem.ToString()+" ("+ listBoxRes.SelectedIndex.ToString()+")";
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            textBoxDNasc.Text = dateTimePicker1.Value.ToShortDateString();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            textBoxDInsc.Text = "De "+monthCalendar1.SelectionStart.ToShortDateString()+" a "+monthCalendar1.SelectionEnd.ToShortDateString();
        }

        private void listBoxLing_SelectedIndexChanged(object sender, EventArgs e)
        {
            string s="";
            foreach(string g in listBoxLing.SelectedItems)
                s +=g+" ";
            textBoxLing.Text = s;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Tem a certeza?", "SAIR", MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.No)
                e.Cancel = true;
        }
    }
}
