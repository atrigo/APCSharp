﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CreateMyRichTextBox();
        }

        public void CreateMyRichTextBox()
        {
            //RichTextBox richTextBox1 = new RichTextBox();
            //this.Controls.Add(richTextBox1);
            richTextBox1.Dock = DockStyle.Fill;
            richTextBox1.LoadFile("Exemplo.rtf");
        }


        private void findToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Find("Text", RichTextBoxFinds.WholeWord);
        }

        private void fonteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionFont = new Font("Verdana", 15, FontStyle.Bold);
        }

        private void vermelhoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionColor = Color.Red;
        }

        private void verdeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionColor = Color.Green;
        }

        private void salvarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SaveFile("Exemplo.rtf", RichTextBoxStreamType.RichText);
        }
    }
}
