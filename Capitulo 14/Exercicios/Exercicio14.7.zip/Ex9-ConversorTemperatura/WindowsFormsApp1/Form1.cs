﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBoxC_TextChanged(object sender, EventArgs e)
        {
            double c, f;
            try
            {
                //c=Convert.ToDouble(textBoxC.Text);
                //f = Math.Round(c * 1.8 + 32,1);
                //textBoxF.Text = Convert.ToString(f);
                textBoxF.Text = Convert.ToString(Math.Round(Convert.ToDouble(textBoxC.Text) * 1.8 + 32,1));
            }
            catch
            {
                textBoxC.Clear();
            }
        }

        private void textBoxF_TextChanged(object sender, EventArgs e)
        {
            double c, f;
            try
            {
                f=Convert.ToDouble(textBoxF.Text);
                c = Math.Round((f - 32)/1.8,1);
                textBoxC.Text = Convert.ToString(c);
            }
            catch
            {
                textBoxF.Clear();
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

        }
    }
}
