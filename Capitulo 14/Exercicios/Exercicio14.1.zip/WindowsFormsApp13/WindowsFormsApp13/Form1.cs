﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            MessageBox.Show(e.ClickedItem.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            comboBox1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            comboBox1.Enabled = false;
        }

        private void contextMenuStrip1_MouseClick(object sender, MouseEventArgs e)
        {
            MessageBox.Show("asdad");
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            MessageBox.Show(toolStripMenuItem9.Text);
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            MessageBox.Show(toolStripMenuItem2.Text);
        }
    }
}
