﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCorFundo_Click(object sender, EventArgs e)
        {
            Random randonGen = new Random();
            this.BackColor = Color.FromArgb(randonGen.Next(255), randonGen.Next(255), randonGen.Next(255));
            toolStripProgressBar1.Increment(5);
            toolStripStatusLabel1.Text = "Cor de fundo alterada";
        }

        private void buttonSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Pretende sair?", "Sair", MessageBoxButtons.OKCancel)== DialogResult.OK)
                Close();
            else
                toolStripStatusLabel1.Text = "Sair cancelado";
        }

        private void meses_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(comboBoxMeses.SelectedIndex)
            {
                case 0: textBTrimestre.Clear(); break;
                case 1:
                case 2:
                case 3: textBTrimestre.Text = "1º Trimestre"; break;
                case 4:
                case 5:
                case 6: textBTrimestre.Text = "2º Trimestre"; break;
                case 7:
                case 8:
                case 9: textBTrimestre.Text = "3º Trimestre"; break;
                case 10:
                case 11:
                case 12: textBTrimestre.Text = "4º Trimestre"; break;
            }
            toolStripProgressBar1.Increment(5);
            toolStripStatusLabel1.Text = "Seleção de mês";
        }

        private void listBsemana_SelectedIndexChanged(object sender, EventArgs e)
        {            
            if (listBoxSemana.SelectedIndex == 0)
                textBsemana.Clear();
            else
                if (listBoxSemana.SelectedIndex > 5)
                    textBsemana.Text = "fim de semana";
                else
                    textBsemana.Text = "dia de trabalho";
            toolStripProgressBar1.Increment(5);
            toolStripStatusLabel1.Text = "Seleção de semana";
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime data = dateTimePicker1.Value;
            textBox1.Text = data.ToShortDateString();
            toolStripProgressBar1.Increment(5);
            toolStripStatusLabel1.Text = "Seleção de data";
        }

        private void vermelhoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackColor = Color.LightSalmon;
        }

        private void verdeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackColor = Color.LightSeaGreen;
        }

        private void azulToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackColor = Color.LightCyan;
        }

        private void gamaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ForeColor = Color.Lime;
        }

        private void verdeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ForeColor = Color.Lime;
        }

        private void azulToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ForeColor = Color.Blue;
        }

        private void vermelhoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ForeColor = Color.Red;
        }

        private void cinzentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackColor = Color.LightGray;
        }
    }
}
