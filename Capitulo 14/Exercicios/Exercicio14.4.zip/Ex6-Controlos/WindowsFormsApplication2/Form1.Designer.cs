﻿namespace WindowsFormsApplication2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.buttonSair = new System.Windows.Forms.Button();
            this.buttonCorFundo = new System.Windows.Forms.Button();
            this.comboBoxMeses = new System.Windows.Forms.ComboBox();
            this.textBTrimestre = new System.Windows.Forms.TextBox();
            this.listBoxSemana = new System.Windows.Forms.ListBox();
            this.textBsemana = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.corDeFundoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vermelhoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verdeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.azulToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gamaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verdeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.azulToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.vermelhoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cinzentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonSair
            // 
            this.buttonSair.Location = new System.Drawing.Point(415, 178);
            this.buttonSair.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSair.Name = "buttonSair";
            this.buttonSair.Size = new System.Drawing.Size(100, 28);
            this.buttonSair.TabIndex = 3;
            this.buttonSair.Text = "Sair";
            this.buttonSair.UseVisualStyleBackColor = true;
            this.buttonSair.Click += new System.EventHandler(this.buttonSair_Click);
            // 
            // buttonCorFundo
            // 
            this.buttonCorFundo.Location = new System.Drawing.Point(414, 114);
            this.buttonCorFundo.Margin = new System.Windows.Forms.Padding(4);
            this.buttonCorFundo.Name = "buttonCorFundo";
            this.buttonCorFundo.Size = new System.Drawing.Size(100, 28);
            this.buttonCorFundo.TabIndex = 4;
            this.buttonCorFundo.Text = "Cor de fundo";
            this.buttonCorFundo.UseVisualStyleBackColor = true;
            this.buttonCorFundo.Click += new System.EventHandler(this.buttonCorFundo_Click);
            // 
            // comboBoxMeses
            // 
            this.comboBoxMeses.FormattingEnabled = true;
            this.comboBoxMeses.Items.AddRange(new object[] {
            "",
            "janeiro",
            "fevereiro",
            "março",
            "abril",
            "maio",
            "junho",
            "julho",
            "agosto",
            "setembro",
            "outubro",
            "novembro",
            "dezembro"});
            this.comboBoxMeses.Location = new System.Drawing.Point(41, 27);
            this.comboBoxMeses.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxMeses.Name = "comboBoxMeses";
            this.comboBoxMeses.Size = new System.Drawing.Size(110, 24);
            this.comboBoxMeses.TabIndex = 5;
            this.comboBoxMeses.SelectedIndexChanged += new System.EventHandler(this.meses_SelectedIndexChanged);
            // 
            // textBTrimestre
            // 
            this.textBTrimestre.Location = new System.Drawing.Point(41, 59);
            this.textBTrimestre.Margin = new System.Windows.Forms.Padding(4);
            this.textBTrimestre.Name = "textBTrimestre";
            this.textBTrimestre.Size = new System.Drawing.Size(110, 22);
            this.textBTrimestre.TabIndex = 6;
            // 
            // listBoxSemana
            // 
            this.listBoxSemana.FormattingEnabled = true;
            this.listBoxSemana.ItemHeight = 16;
            this.listBoxSemana.Items.AddRange(new object[] {
            "",
            "segunda-feira",
            "terça-feira",
            "quarta-feira",
            "quinta-feira",
            "sexta-feira",
            "sábado",
            "domingo"});
            this.listBoxSemana.Location = new System.Drawing.Point(41, 105);
            this.listBoxSemana.Margin = new System.Windows.Forms.Padding(4);
            this.listBoxSemana.Name = "listBoxSemana";
            this.listBoxSemana.Size = new System.Drawing.Size(121, 68);
            this.listBoxSemana.TabIndex = 7;
            this.listBoxSemana.SelectedIndexChanged += new System.EventHandler(this.listBsemana_SelectedIndexChanged);
            // 
            // textBsemana
            // 
            this.textBsemana.Location = new System.Drawing.Point(41, 181);
            this.textBsemana.Margin = new System.Windows.Forms.Padding(4);
            this.textBsemana.Multiline = true;
            this.textBsemana.Name = "textBsemana";
            this.textBsemana.Size = new System.Drawing.Size(124, 20);
            this.textBsemana.TabIndex = 8;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(321, 29);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(194, 22);
            this.dateTimePicker1.TabIndex = 12;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(322, 61);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(193, 20);
            this.textBox1.TabIndex = 8;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripProgressBar1,
            this.toolStripSplitButton1,
            this.toolStripDropDownButton1,
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 267);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(528, 22);
            this.statusStrip1.TabIndex = 13;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Maximum = 20;
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(200, 16);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(22, 17);
            this.toolStripStatusLabel1.Text = "---";
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.corDeFundoToolStripMenuItem});
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(32, 20);
            this.toolStripSplitButton1.Text = "toolStripSplitButton1";
            this.toolStripSplitButton1.ToolTipText = "Cor de Fundo";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gamaToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 20);
            this.toolStripDropDownButton1.Text = "toolStripDropDownButton1";
            // 
            // corDeFundoToolStripMenuItem
            // 
            this.corDeFundoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vermelhoToolStripMenuItem,
            this.verdeToolStripMenuItem,
            this.azulToolStripMenuItem,
            this.cinzentoToolStripMenuItem});
            this.corDeFundoToolStripMenuItem.Name = "corDeFundoToolStripMenuItem";
            this.corDeFundoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.corDeFundoToolStripMenuItem.Text = "Cor de Fundo";
            // 
            // vermelhoToolStripMenuItem
            // 
            this.vermelhoToolStripMenuItem.Name = "vermelhoToolStripMenuItem";
            this.vermelhoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.vermelhoToolStripMenuItem.Text = "Vermelho";
            this.vermelhoToolStripMenuItem.Click += new System.EventHandler(this.vermelhoToolStripMenuItem_Click);
            // 
            // verdeToolStripMenuItem
            // 
            this.verdeToolStripMenuItem.Name = "verdeToolStripMenuItem";
            this.verdeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.verdeToolStripMenuItem.Text = "Verde";
            this.verdeToolStripMenuItem.Click += new System.EventHandler(this.verdeToolStripMenuItem_Click);
            // 
            // azulToolStripMenuItem
            // 
            this.azulToolStripMenuItem.Name = "azulToolStripMenuItem";
            this.azulToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.azulToolStripMenuItem.Text = "Azul";
            this.azulToolStripMenuItem.Click += new System.EventHandler(this.azulToolStripMenuItem_Click);
            // 
            // gamaToolStripMenuItem
            // 
            this.gamaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.verdeToolStripMenuItem1,
            this.azulToolStripMenuItem1,
            this.vermelhoToolStripMenuItem1});
            this.gamaToolStripMenuItem.Name = "gamaToolStripMenuItem";
            this.gamaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.gamaToolStripMenuItem.Text = "Cor de texto";
            this.gamaToolStripMenuItem.Click += new System.EventHandler(this.gamaToolStripMenuItem_Click);
            // 
            // verdeToolStripMenuItem1
            // 
            this.verdeToolStripMenuItem1.Name = "verdeToolStripMenuItem1";
            this.verdeToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.verdeToolStripMenuItem1.Text = "Verde";
            this.verdeToolStripMenuItem1.Click += new System.EventHandler(this.verdeToolStripMenuItem1_Click);
            // 
            // azulToolStripMenuItem1
            // 
            this.azulToolStripMenuItem1.Name = "azulToolStripMenuItem1";
            this.azulToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.azulToolStripMenuItem1.Text = "Azul";
            this.azulToolStripMenuItem1.Click += new System.EventHandler(this.azulToolStripMenuItem1_Click);
            // 
            // vermelhoToolStripMenuItem1
            // 
            this.vermelhoToolStripMenuItem1.Name = "vermelhoToolStripMenuItem1";
            this.vermelhoToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.vermelhoToolStripMenuItem1.Text = "Vermelho";
            this.vermelhoToolStripMenuItem1.Click += new System.EventHandler(this.vermelhoToolStripMenuItem1_Click);
            // 
            // cinzentoToolStripMenuItem
            // 
            this.cinzentoToolStripMenuItem.Name = "cinzentoToolStripMenuItem";
            this.cinzentoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.cinzentoToolStripMenuItem.Text = "Cinzento";
            this.cinzentoToolStripMenuItem.Click += new System.EventHandler(this.cinzentoToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(528, 289);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBsemana);
            this.Controls.Add(this.listBoxSemana);
            this.Controls.Add(this.textBTrimestre);
            this.Controls.Add(this.comboBoxMeses);
            this.Controls.Add(this.buttonCorFundo);
            this.Controls.Add(this.buttonSair);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Teste";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonSair;
        private System.Windows.Forms.Button buttonCorFundo;
        private System.Windows.Forms.ComboBox comboBoxMeses;
        private System.Windows.Forms.TextBox textBTrimestre;
        private System.Windows.Forms.ListBox listBoxSemana;
        private System.Windows.Forms.TextBox textBsemana;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem corDeFundoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vermelhoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verdeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem azulToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gamaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verdeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem azulToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem vermelhoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cinzentoToolStripMenuItem;
    }
}

