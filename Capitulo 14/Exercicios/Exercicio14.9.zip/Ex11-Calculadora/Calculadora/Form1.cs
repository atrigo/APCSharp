﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Calculadora : Form
    {
        string op1 = "",op="";
        public Calculadora()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, EventArgs e)
        {
            Button b = sender as Button;
            if (textBoxVisor.Text == "0")
                textBoxVisor.Text = b.Text;
            else
                textBoxVisor.Text += b.Text;
        }

         private void buttonVirg_Click(object sender, EventArgs e)
         {
             if(textBoxVisor.Text.Contains(",")==false)
                 textBoxVisor.Text+=",";
         }

         private void buttonSinal_Click(object sender, EventArgs e)
         {
             textBoxVisor.Text=Convert.ToString(-1*Convert.ToDouble(textBoxVisor.Text));
         }

         private void buttonC_Click(object sender, EventArgs e)
         {
             textBoxVisor.Text ="0";
             op = "";
             op1="";
         }

         private void buttonCE_Click(object sender, EventArgs e)
         {
             textBoxVisor.Text = "0";
         }

         private void buttonBS_Click(object sender, EventArgs e)
         {
             if ( textBoxVisor.Text.Length != 0)
             {
                textBoxVisor.Text = textBoxVisor.Text.Remove(textBoxVisor.Text.Length- 1);
                if (textBoxVisor.Text.Length == 0 || textBoxVisor.Text == "-")
                    textBoxVisor.Text = "0";
             }
         }

         private void buttonInv_Click(object sender, EventArgs e)
         {
             try
             {
                 textBoxVisor.Text = Convert.ToString(1 / Convert.ToDouble(textBoxVisor.Text));
             }
             catch
             {
                 textBoxVisor.Text = "0";
             }

         }

         private void buttonQuad_Click(object sender, EventArgs e)
         {
             try
             {
                 textBoxVisor.Text = Convert.ToString(Math.Pow( Convert.ToDouble(textBoxVisor.Text),2));
             }
             catch
             {
                 textBoxVisor.Text = "0";
             }

         }

         private void buttonRQ_Click(object sender, EventArgs e)
         {
             try
             {
                 textBoxVisor.Text = Convert.ToString(Math.Sqrt( Convert.ToDouble(textBoxVisor.Text)));
             }
             catch
             {
                 textBoxVisor.Text = "0";
             }
         }

         private void buttonPercent_Click(object sender, EventArgs e)
         {
             try
             {
                 if(op=="")
                     textBoxVisor.Text = "0";
                 else
                    textBoxVisor.Text = Convert.ToString(Convert.ToDouble(op1) * Convert.ToDouble(textBoxVisor.Text) / 100);
             }
             catch
             {
                 textBoxVisor.Text = "0";
             }

         }        
 
         private void buttonOP_Click(object sender, EventArgs e)
         {
            Button b = sender as Button;
            op1 = textBoxVisor.Text;
            textBoxVisor.Text="0";
            op = b.Text;
         }

         private void buttonRes_Click(object sender, EventArgs e)
         {
             try
             {
                 switch(op)
                 {
                     case "+": textBoxVisor.Text = Convert.ToString(Convert.ToDouble(op1) + Convert.ToDouble(textBoxVisor.Text)); break;
                     case "-": textBoxVisor.Text = Convert.ToString(Convert.ToDouble(op1) - Convert.ToDouble(textBoxVisor.Text)); break;
                     case "x": textBoxVisor.Text = Convert.ToString(Convert.ToDouble(op1) * Convert.ToDouble(textBoxVisor.Text)); break;
                     case "/": textBoxVisor.Text = Convert.ToString(Convert.ToDouble(op1) / Convert.ToDouble(textBoxVisor.Text)); break;

                 }
             }
             catch
             {
                 textBoxVisor.Text = "0";
             }
         }

        private void textBoxVisor_TextChanged(object sender, EventArgs e)
        {

        }

        private void Calculadora_Load(object sender, EventArgs e)
         {
  //           this.ActiveControl = textBoxVisor;
         }

     }
}
