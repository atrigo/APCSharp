﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            textBox3.Text = (numericUpDown1.Value * 2).ToString();
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            textBox8.Text = (numericUpDown2.Value * 2).ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                textBox2.Text = (Convert.ToDouble(textBox1.Text.ToString()) * 2).ToString();
            }
            catch {
                textBox2.Clear();
                toolTip1.ToolTipTitle = "Carácter inválido";
                toolTip1.Show("Introduza apenas números de 0 a 9", textBox2, 0, -20, 3000);

            }
        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            try
            {
                textBox6.Text = (Convert.ToInt32(textBox5.Text.ToString()) * 2).ToString();
            }
            catch
            {
                textBox5.Clear();
                toolTip1.ToolTipTitle = "Carácter inválido";
                toolTip1.Show("Introduza apenas números de 0 a 9", textBox5, 0, -20, 3000);
            }
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }


        private void Form1_Load(object sender, EventArgs e)
        {
            maskedTextBox1.ValidatingType = typeof(double);
            maskedTextBox2.ValidatingType = typeof(int);
        }

        private void maskedTextBox1_TypeValidationCompleted_1(object sender, TypeValidationEventArgs e)
        {
            if (e.IsValidInput)
            {
                textBox4.Text = ((double)e.ReturnValue * 2).ToString();
            }
            else
            {
                toolTip1.ToolTipTitle = "Carácter inválido";
                toolTip1.Show("Introduza apenas números de 0 a 9 e o separador decimal", maskedTextBox1, 0, -20, 3000);
            }
        }

        private void maskedTextBox2_TypeValidationCompleted(object sender, TypeValidationEventArgs e)
        {
            if (e.IsValidInput)
            {
                textBox7.Text = ((int)e.ReturnValue * 2).ToString();
            }
            else
            {
                toolTip1.ToolTipTitle = "Carácter inválido";
                toolTip1.Show("Introduza apenas números de 0 a 9", maskedTextBox2, 0, -20, 3000);
            }
        }
    }
}
