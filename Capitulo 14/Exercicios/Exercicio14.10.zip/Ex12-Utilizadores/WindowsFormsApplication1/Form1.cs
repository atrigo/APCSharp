﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        string genero = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void rotulo_Click(object sender, EventArgs e)
        {
                Close();
        }

        private void form1_Closing(object sender, FormClosingEventArgs e)
        {
                DialogResult res;
                res = MessageBox.Show("Pretende sair?", "SAIR", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == DialogResult.No)
                    e.Cancel = true;
        }

        private void buttonSair_Click(object sender, EventArgs e)
        {
                Close();
        }



        private void focus(object sender, EventArgs e)
        {
                Close();

        }

        private void buttonL_Click(object sender, EventArgs e)
        {
            textBoxPN.Clear();
            textBoxA.Clear();
            maskedTextBoxCP.Clear();
            textBoxEmail.Clear();
            dateTimePicker1.Value = DateTime.Today;
            radioButtonF.Checked = false;
            radioButtonM.Checked = false;
            comboBoxP.Text = "";
            comboBoxC.SelectedIndex = 0;
            //comboBoxC.Text = "";
        }

        private void comboBoxP_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxC.Items.Clear();
            switch (comboBoxP.SelectedIndex)
            {
                case 0: comboBoxC.Items.AddRange(new object[] { ""}); break;
                case 1: comboBoxC.Items.AddRange(new object[] { "", "Berlim", "Hamburgo", "Munique", "Nuremberga"}); break;
                case 2: comboBoxC.Items.AddRange(new object[] { "", "Bordéus", "Lyon", "Paris", "Toulouse" }); break;
                case 3: comboBoxC.Items.AddRange(new object[] { "", "Coimbra", "Guarda", "Lisboa", "Porto" }); break;
                case 4: comboBoxC.Items.AddRange(new object[] { "", "Berna", "Genebra", "Lausanne", "Zurique"}); break;
            }
            comboBoxC.SelectedIndex = 0;
        }

        private void buttonMMB_Click(object sender, EventArgs e)
        {
            MessageBox.Show(textBoxPN.Text + " - " + textBoxA.Text + " - " + textBoxEmail.Text + " - " + dateTimePicker1.Text
                            + " - " +genero+ " - " +comboBoxP.Text+ " - " +comboBoxC.Text+ " - " +maskedTextBoxCP.Text);
        }

        private void radioButtonF_CheckedChanged(object sender, EventArgs e)
        {
            genero = radioButtonF.Text;
        }

        private void radioButtonM_CheckedChanged(object sender, EventArgs e)
        {
            genero = radioButtonM.Text;
        }
    }   
}
