﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelPN = new System.Windows.Forms.Label();
            this.textBoxPN = new System.Windows.Forms.TextBox();
            this.labelA = new System.Windows.Forms.Label();
            this.textBoxA = new System.Windows.Forms.TextBox();
            this.labelEmail = new System.Windows.Forms.Label();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.labelDN = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.radioButtonF = new System.Windows.Forms.RadioButton();
            this.radioButtonM = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBoxP = new System.Windows.Forms.ComboBox();
            this.comboBoxC = new System.Windows.Forms.ComboBox();
            this.buttonL = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.labelApelido = new System.Windows.Forms.Label();
            this.maskedTextBoxCP = new System.Windows.Forms.MaskedTextBox();
            this.buttonM = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelPN
            // 
            this.labelPN.AutoSize = true;
            this.labelPN.Location = new System.Drawing.Point(37, 16);
            this.labelPN.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPN.Name = "labelPN";
            this.labelPN.Size = new System.Drawing.Size(98, 16);
            this.labelPN.TabIndex = 0;
            this.labelPN.Text = "Primeiro Nome";
            // 
            // textBoxPN
            // 
            this.textBoxPN.Location = new System.Drawing.Point(154, 14);
            this.textBoxPN.Name = "textBoxPN";
            this.textBoxPN.Size = new System.Drawing.Size(123, 22);
            this.textBoxPN.TabIndex = 1;
            // 
            // labelA
            // 
            this.labelA.AutoSize = true;
            this.labelA.Location = new System.Drawing.Point(215, 116);
            this.labelA.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelA.Name = "labelA";
            this.labelA.Size = new System.Drawing.Size(35, 16);
            this.labelA.TabIndex = 0;
            this.labelA.Text = "País";
            // 
            // textBoxA
            // 
            this.textBoxA.Location = new System.Drawing.Point(425, 14);
            this.textBoxA.Name = "textBoxA";
            this.textBoxA.Size = new System.Drawing.Size(139, 22);
            this.textBoxA.TabIndex = 1;
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Location = new System.Drawing.Point(37, 60);
            this.labelEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(42, 16);
            this.labelEmail.TabIndex = 0;
            this.labelEmail.Text = "Email";
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(106, 57);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(123, 22);
            this.textBoxEmail.TabIndex = 1;
            // 
            // labelDN
            // 
            this.labelDN.AutoSize = true;
            this.labelDN.Location = new System.Drawing.Point(277, 60);
            this.labelDN.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelDN.Name = "labelDN";
            this.labelDN.Size = new System.Drawing.Size(131, 16);
            this.labelDN.TabIndex = 0;
            this.labelDN.Text = "Data de Nascimento";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(415, 57);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(149, 22);
            this.dateTimePicker1.TabIndex = 2;
            // 
            // radioButtonF
            // 
            this.radioButtonF.AutoSize = true;
            this.radioButtonF.Location = new System.Drawing.Point(20, 21);
            this.radioButtonF.Name = "radioButtonF";
            this.radioButtonF.Size = new System.Drawing.Size(81, 20);
            this.radioButtonF.TabIndex = 3;
            this.radioButtonF.TabStop = true;
            this.radioButtonF.Text = "Feminino";
            this.radioButtonF.UseVisualStyleBackColor = true;
            this.radioButtonF.CheckedChanged += new System.EventHandler(this.radioButtonF_CheckedChanged);
            // 
            // radioButtonM
            // 
            this.radioButtonM.AutoSize = true;
            this.radioButtonM.Location = new System.Drawing.Point(20, 47);
            this.radioButtonM.Name = "radioButtonM";
            this.radioButtonM.Size = new System.Drawing.Size(87, 20);
            this.radioButtonM.TabIndex = 3;
            this.radioButtonM.TabStop = true;
            this.radioButtonM.Text = "Masculino";
            this.radioButtonM.UseVisualStyleBackColor = true;
            this.radioButtonM.CheckedChanged += new System.EventHandler(this.radioButtonM_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtonM);
            this.groupBox1.Controls.Add(this.radioButtonF);
            this.groupBox1.Location = new System.Drawing.Point(40, 99);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(134, 79);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Género";
            // 
            // comboBoxP
            // 
            this.comboBoxP.FormattingEnabled = true;
            this.comboBoxP.Items.AddRange(new object[] {
            "",
            "Alemanha",
            "França",
            "Portugal",
            "Suiça"});
            this.comboBoxP.Location = new System.Drawing.Point(276, 113);
            this.comboBoxP.Name = "comboBoxP";
            this.comboBoxP.Size = new System.Drawing.Size(132, 24);
            this.comboBoxP.TabIndex = 5;
            this.comboBoxP.SelectedIndexChanged += new System.EventHandler(this.comboBoxP_SelectedIndexChanged);
            // 
            // comboBoxC
            // 
            this.comboBoxC.FormattingEnabled = true;
            this.comboBoxC.Location = new System.Drawing.Point(276, 154);
            this.comboBoxC.Name = "comboBoxC";
            this.comboBoxC.Size = new System.Drawing.Size(132, 24);
            this.comboBoxC.TabIndex = 5;
            // 
            // buttonL
            // 
            this.buttonL.Location = new System.Drawing.Point(450, 227);
            this.buttonL.Name = "buttonL";
            this.buttonL.Size = new System.Drawing.Size(112, 27);
            this.buttonL.TabIndex = 7;
            this.buttonL.Text = "Limpar";
            this.buttonL.UseVisualStyleBackColor = true;
            this.buttonL.Click += new System.EventHandler(this.buttonL_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(215, 157);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cidade";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.maskedTextBoxCP);
            this.groupBox2.Location = new System.Drawing.Point(437, 113);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(127, 64);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Código Postal";
            // 
            // labelApelido
            // 
            this.labelApelido.AutoSize = true;
            this.labelApelido.Location = new System.Drawing.Point(346, 16);
            this.labelApelido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelApelido.Name = "labelApelido";
            this.labelApelido.Size = new System.Drawing.Size(55, 16);
            this.labelApelido.TabIndex = 0;
            this.labelApelido.Text = "Apelido";
            // 
            // maskedTextBoxCP
            // 
            this.maskedTextBoxCP.Location = new System.Drawing.Point(16, 28);
            this.maskedTextBoxCP.Mask = "0000-000";
            this.maskedTextBoxCP.Name = "maskedTextBoxCP";
            this.maskedTextBoxCP.Size = new System.Drawing.Size(92, 22);
            this.maskedTextBoxCP.TabIndex = 0;
            this.maskedTextBoxCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonM
            // 
            this.buttonM.Location = new System.Drawing.Point(38, 227);
            this.buttonM.Name = "buttonM";
            this.buttonM.Size = new System.Drawing.Size(96, 26);
            this.buttonM.TabIndex = 9;
            this.buttonM.Text = "Mostrar";
            this.buttonM.UseVisualStyleBackColor = true;
            this.buttonM.Click += new System.EventHandler(this.buttonMMB_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(595, 274);
            this.Controls.Add(this.buttonM);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.buttonL);
            this.Controls.Add(this.comboBoxC);
            this.Controls.Add(this.comboBoxP);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.textBoxA);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.textBoxPN);
            this.Controls.Add(this.labelDN);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelA);
            this.Controls.Add(this.labelApelido);
            this.Controls.Add(this.labelEmail);
            this.Controls.Add(this.labelPN);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Teste";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.form1_Closing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelPN;
        private System.Windows.Forms.TextBox textBoxPN;
        private System.Windows.Forms.Label labelA;
        private System.Windows.Forms.TextBox textBoxA;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.Label labelDN;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.RadioButton radioButtonF;
        private System.Windows.Forms.RadioButton radioButtonM;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBoxP;
        private System.Windows.Forms.ComboBox comboBoxC;
        private System.Windows.Forms.Button buttonL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxCP;
        private System.Windows.Forms.Label labelApelido;
        private System.Windows.Forms.Button buttonM;
    }
}

