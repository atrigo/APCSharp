﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        string genero = "";
        int posicao = 0; //variavel que contem a posicao dos dados do vetor que se está a ver no formulário
        int ultimaPosicao = 0; //variavel que contem a ultima posicao dos dados no vetor (tem de ser inferior à dimensão do vetor)
        
        List<Utilizador> utilizadores = new List<Utilizador>();


        public Form1()
        {
            InitializeComponent();
            utilizadores.Add(new Utilizador());
        }

        private void form1_Closing(object sender, FormClosingEventArgs e)
        {
                DialogResult res;
                res = MessageBox.Show("Pretende sair?", "SAIR", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == DialogResult.No)
                    e.Cancel = true;
        }

        private void buttonLimpar_Click(object sender, EventArgs e) //Limpar
        {
            textBoxPN.Clear();
            textBoxA.ResetText();
            maskedTextBoxCP.Clear();
            textBoxEmail.Clear();
            dateTimePicker1.Value = DateTime.Today;
            radioButtonF.Checked = false;
            radioButtonM.Checked = false;
            comboBoxP.ResetText();
            comboBoxC.SelectedIndex = 0;
        }

        private void comboBoxP_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxC.Items.Clear();
            switch (comboBoxP.SelectedIndex)
            {
                case 0: comboBoxC.Items.AddRange(new object[] { ""}); break;
                case 1: comboBoxC.Items.AddRange(new object[] { "", "Berlim", "Hamburgo", "Munique", "Nuremberga"}); break;
                case 2: comboBoxC.Items.AddRange(new object[] { "", "Bordéus", "Lyon", "Paris", "Toulouse" }); break;
                case 3: comboBoxC.Items.AddRange(new object[] { "", "Coimbra", "Guarda", "Lisboa", "Porto" }); break;
                case 4: comboBoxC.Items.AddRange(new object[] { "", "Berna", "Genebra", "Lausanne", "Zurique"}); break;
            }
            comboBoxC.SelectedIndex = 0;
        }

        private void buttonGravar_Click(object sender, EventArgs e)
        {
            utilizadores[posicao].Nome = textBoxPN.Text;
            utilizadores[posicao].Apelido = textBoxA.Text;
            utilizadores[posicao].Email = textBoxEmail.Text;
            utilizadores[posicao].DataNascimento = dateTimePicker1.Text;
            utilizadores[posicao].Genero = genero;
            utilizadores[posicao].Pais = comboBoxP.Text;
            utilizadores[posicao].Cidade = comboBoxC.Text;
            utilizadores[posicao].Codigo = maskedTextBoxCP.Text;
            MessageBox.Show("Registo guardado com sucesso.");
        }

        private void Preencher()
        {
            textBoxPN.Text= utilizadores[posicao].Nome;
            textBoxA.Text = utilizadores[posicao].Apelido;
            textBoxEmail.Text = utilizadores[posicao].Email;
            dateTimePicker1.Text= utilizadores[posicao].DataNascimento;
            if (utilizadores[posicao].Genero == "Feminino")
                radioButtonF.Checked = true;
            if (utilizadores[posicao].Genero == "Masculino")
                radioButtonM.Checked = true;
            comboBoxP.Text= utilizadores[posicao].Pais;
            comboBoxC.Text = utilizadores[posicao].Cidade;
            maskedTextBoxCP.Text= utilizadores[posicao].Codigo;
        }

        private void radioButtonF_CheckedChanged(object sender, EventArgs e)
        {
            genero = radioButtonF.Text;
        }

        private void radioButtonM_CheckedChanged(object sender, EventArgs e)
        {
            genero = radioButtonM.Text;
        }

        private void buttonN_Click(object sender, EventArgs e)
        {
            ultimaPosicao++;
            utilizadores.Add(new Utilizador());
            posicao = ultimaPosicao;
            buttonLimpar_Click(sender, e);
            labelP.Text = Convert.ToString(posicao);
        }

        private void buttonA_Click(object sender, EventArgs e)
        {
            if (posicao > 0)
            {
                posicao--;
                Preencher();
                labelP.Text = Convert.ToString(posicao);
            }
            else
                MessageBox.Show("Já está no primeiro!");
        }

        private void buttonProx_Click(object sender, EventArgs e)
        {
            if (posicao < ultimaPosicao)
            {
                posicao++;
                Preencher();
                labelP.Text = Convert.ToString(posicao);
            }
            else
                MessageBox.Show("Já está no ultimo!");
        }

        private void buttonPrim_Click(object sender, EventArgs e)
        {
            posicao = 0;
            Preencher();
            labelP.Text = Convert.ToString(posicao);
        }

        private void buttonU_Click(object sender, EventArgs e)
        {
            posicao = ultimaPosicao;
            Preencher();
            labelP.Text = Convert.ToString(posicao);
        }
    }   
}
