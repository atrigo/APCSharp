﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class Utilizador
    {
        public string Nome { get; set; }
        public string Apelido { get; set; }
        public string Email { get; set; }
        public string DataNascimento { get; set; }
        public string Genero { get; set; }
        public string Pais { get; set; }
        public string Cidade { get; set; }
        public string Codigo { get; set; }

    }
}
