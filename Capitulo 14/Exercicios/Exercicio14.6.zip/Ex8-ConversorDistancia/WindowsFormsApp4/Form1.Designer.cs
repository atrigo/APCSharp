﻿using System;

namespace WindowsFormsApp4
{
    partial class Conversor
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBoxMilhas = new System.Windows.Forms.TextBox();
            this.textBoxKm = new System.Windows.Forms.TextBox();
            this.buttonConvMiKm = new System.Windows.Forms.Button();
            this.labelMi = new System.Windows.Forms.Label();
            this.labelKm = new System.Windows.Forms.Label();
            this.buttonConvKmMi = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // textBoxMilhas
            // 
            this.textBoxMilhas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMilhas.Location = new System.Drawing.Point(123, 12);
            this.textBoxMilhas.Name = "textBoxMilhas";
            this.textBoxMilhas.Size = new System.Drawing.Size(165, 26);
            this.textBoxMilhas.TabIndex = 0;
            this.textBoxMilhas.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxMilhas.TextChanged += new System.EventHandler(this.textBoxMilhas_TextChanged);
            // 
            // textBoxKm
            // 
            this.textBoxKm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxKm.Location = new System.Drawing.Point(123, 54);
            this.textBoxKm.Name = "textBoxKm";
            this.textBoxKm.Size = new System.Drawing.Size(163, 26);
            this.textBoxKm.TabIndex = 1;
            this.textBoxKm.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonConvMiKm
            // 
            this.buttonConvMiKm.Location = new System.Drawing.Point(12, 111);
            this.buttonConvMiKm.Name = "buttonConvMiKm";
            this.buttonConvMiKm.Size = new System.Drawing.Size(129, 25);
            this.buttonConvMiKm.TabIndex = 2;
            this.buttonConvMiKm.Text = "Converter Mi>>Km";
            this.buttonConvMiKm.UseVisualStyleBackColor = true;
            this.buttonConvMiKm.Click += new System.EventHandler(this.buttonConvMiKm_Click);
            // 
            // labelMi
            // 
            this.labelMi.AutoSize = true;
            this.labelMi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMi.Location = new System.Drawing.Point(40, 15);
            this.labelMi.Name = "labelMi";
            this.labelMi.Size = new System.Drawing.Size(54, 20);
            this.labelMi.TabIndex = 3;
            this.labelMi.Text = "Milhas";
            // 
            // labelKm
            // 
            this.labelKm.AutoSize = true;
            this.labelKm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelKm.Location = new System.Drawing.Point(40, 57);
            this.labelKm.Name = "labelKm";
            this.labelKm.Size = new System.Drawing.Size(32, 20);
            this.labelKm.TabIndex = 3;
            this.labelKm.Text = "Km";
            // 
            // buttonConvKmMi
            // 
            this.buttonConvKmMi.Location = new System.Drawing.Point(157, 111);
            this.buttonConvKmMi.Name = "buttonConvKmMi";
            this.buttonConvKmMi.Size = new System.Drawing.Size(129, 25);
            this.buttonConvKmMi.TabIndex = 2;
            this.buttonConvKmMi.Text = "Converter Km>>Mi";
            this.buttonConvKmMi.UseVisualStyleBackColor = true;
            this.buttonConvKmMi.Click += new System.EventHandler(this.buttonConvKmMi_Click);
            // 
            // Conversor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 148);
            this.Controls.Add(this.labelKm);
            this.Controls.Add(this.labelMi);
            this.Controls.Add(this.buttonConvKmMi);
            this.Controls.Add(this.buttonConvMiKm);
            this.Controls.Add(this.textBoxKm);
            this.Controls.Add(this.textBoxMilhas);
            this.Name = "Conversor";
            this.Text = "Conversor de distância";
            this.ResumeLayout(false);
            this.PerformLayout();

        }



        #endregion

        private System.Windows.Forms.TextBox textBoxMilhas;
        private System.Windows.Forms.TextBox textBoxKm;
        private System.Windows.Forms.Button buttonConvMiKm;
        private System.Windows.Forms.Label labelMi;
        private System.Windows.Forms.Label labelKm;
        private System.Windows.Forms.Button buttonConvKmMi;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

