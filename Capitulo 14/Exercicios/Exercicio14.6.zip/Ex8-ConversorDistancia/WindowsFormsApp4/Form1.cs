﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Conversor : Form
    {
        public Conversor()
        {
            InitializeComponent();
        }

        private void buttonConvMiKm_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxKm.Text = Convert.ToString(Math.Round(Convert.ToDouble(textBoxMilhas.Text) * 1.609344,2));
            }
            catch(Exception x)
            {
                toolTip1.ToolTipTitle = "ERRO";
                toolTip1.Show(x.Message, textBoxMilhas,2000);
            }
        }
        private void buttonConvKmMi_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxMilhas.Text = Convert.ToString(Math.Round(Convert.ToDouble(textBoxKm.Text) / 1.609344,2));
            }
            catch(Exception x)
            {
                toolTip1.ToolTipTitle = "ERRO";
                toolTip1.Show(x.Message, textBoxKm,2000);
            }           
        }

        private void textBoxMilhas_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
