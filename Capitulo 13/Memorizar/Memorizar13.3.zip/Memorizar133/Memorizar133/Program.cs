﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Memorizar133
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Pessoa> pessoas1 = new List<Pessoa>();
            for (int i = 0; i < 10; i++)
            {
                Pessoa p = new Pessoa();
                p.Nome = "Helena";
                p.Idade = 10 + i;
                pessoas1.Add(p);
            }
            FileStream fs1 = new FileStream("pessoas.dat",
                FileMode.Create, FileAccess.Write);
            BinaryFormatter bf1 = new BinaryFormatter();
            bf1.Serialize(fs1, pessoas1);
            fs1.Close();
            FileStream fs2 = new FileStream("pessoas.dat",
                FileMode.Open, FileAccess.Read);
            BinaryFormatter bf2 = new BinaryFormatter();
            List<Pessoa> pessoas2 = new List<Pessoa>();
            pessoas2 = (List<Pessoa>)bf2.Deserialize(fs2);
            foreach (Pessoa p in pessoas2)
                Console.WriteLine("Nome: {0} Idade: {1}", p.Nome, p.Idade);
            fs2.Close();
        }
    }
}
