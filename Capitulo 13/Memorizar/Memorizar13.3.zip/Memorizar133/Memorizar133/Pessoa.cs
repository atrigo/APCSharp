﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memorizar133
{
    [Serializable]
    public class Pessoa
    {
        public string Nome{ get; set;  }
        public int Idade{ get; set; }

    }
}
