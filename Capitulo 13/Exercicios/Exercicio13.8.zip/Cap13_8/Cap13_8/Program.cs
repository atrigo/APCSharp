﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cap13_8
{
    class Program
    {
        static Cliente preenche()
        {
            Cliente c = new Cliente();
            Console.Write("Nome:");
            c.Nome = Console.ReadLine();
            Console.Write("Número de cliente:");
            c.NC = Convert.ToInt32(Console.ReadLine());
            Console.Write("Saldo:");
            c.Saldo = Convert.ToSingle(Console.ReadLine());
            Console.Write("Data de nascimento (aaaa-mm-dd):");
            c.Aniv = Convert.ToDateTime(Console.ReadLine());
            return c;
        }

        static void adicionaCliente(List<Cliente> lc)
        {
            lc.Add(preenche());
        }

        static void apresenta(List<Cliente> lc)
        {
            Console.WriteLine("{0,-15}{1,-3}{2,-6}{3,-12}", "NOME", "NC", "SALDO", "DATA");
            foreach(Cliente c in lc)
                Console.WriteLine("{0,-15}{1,-3}{2,-6}{3,-12}", c.Nome, c.NC, c.Saldo, c.Aniv.ToShortDateString());
        }

        static void guardaLista(List<Cliente> t)
        {
            try
            {
                FileStream BFS = new FileStream("Clientes.bin", FileMode.Create, FileAccess.Write);
                BinaryWriter BW = new BinaryWriter(BFS);
                foreach (Cliente a in t)
                {
                    BW.Write(a.Nome);//Leitura: ReadString()
                    BW.Write(a.NC);//Leitura: ReadInt32()
                    BW.Write(a.Saldo);//Leitura: ReadSingle()
                    BW.Write(a.Aniv.ToShortDateString());//Leitura: ReadString()
                }
                BW.Close();
                BFS.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void carregaLista(ref List<Cliente> t)
        {
            try
            {
                FileStream BFR = new FileStream("Clientes.bin", FileMode.Open, FileAccess.Read);
                BinaryReader BR = new BinaryReader(BFR);
                while (BR.PeekChar() != -1)
                {
                    t.Add(new Cliente(BR.ReadString(), BR.ReadInt32(), BR.ReadSingle(), Convert.ToDateTime(BR.ReadString())));
                }
                BR.Close();
                BFR.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void Main(string[] args)
        {
            List<Cliente> lc = new List<Cliente>();
            //lc.Add(new Cliente("Rui Lopes", 1, 425.8F, new DateTime(2000, 1, 1)));
            //lc.Add(new Cliente("Ana Gomes", 2, 542.65F, new DateTime(2001, 2, 3)));
            carregaLista(ref lc);
            adicionaCliente(lc);
            apresenta(lc);
            guardaLista(lc);
        }
    }
}
