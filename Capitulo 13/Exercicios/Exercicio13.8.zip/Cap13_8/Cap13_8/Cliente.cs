﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cap13_8
{
    class Cliente
    {
        public string Nome { get; set; }
        public int NC { get; set; }
        public float Saldo { get; set; }
        public DateTime Aniv { get; set; }

        public Cliente() { }
        public Cliente(string n, int nc, float s, DateTime a) 
        {
            Nome = n;
            NC = nc;
            Saldo = s;
            Aniv = a;
        }
    }
}
