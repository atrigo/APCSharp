﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FP6_EX4
{
    public partial class FormLogin : Form
    {
        public string Username { get; set; }
        public FormLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int contar = utilizadorTableAdapter1.GetDataByUsernamePassword(
                textBoxUsername.Text, textBoxPassword.Text).Count;

            if (contar > 0) {
                Username = utilizadorTableAdapter1.GetDataByUsernamePassword(
                textBoxUsername.Text, textBoxPassword.Text).First().Username;
                MessageBox.Show("Autenticado com sucesso!");
                Close();
            }
            else
            {
                MessageBox.Show("Credenciais erradas");
                Close();
            }
        }
    }
}
