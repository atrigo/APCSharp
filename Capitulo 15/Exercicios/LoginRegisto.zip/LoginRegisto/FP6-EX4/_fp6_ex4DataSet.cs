﻿namespace FP6_EX4
{


    partial class _fp6_ex4DataSet
    {
    }
}

namespace FP6_EX4._fp6_ex4DataSetTableAdapters {
    
    
    public partial class UtilizadorTableAdapter {
    }
}
