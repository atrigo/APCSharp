﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FP6_EX4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormRegisto fr = new FormRegisto();
            fr.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormLogin fl = new FormLogin();
            fl.ShowDialog();
            if (fl.Username == null || fl.Username != "")
            {
                label1.Text = "Utilizador: " + fl.Username;
            }
            else
            {
                label1.Text = "Utilizador anónimo";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            StreamWriter sw = new StreamWriter("utilizadores.txt");
            foreach (_fp6_ex4DataSet.UtilizadorRow row in utilizadorTableAdapter1.GetData().Rows)
            {
                sw.WriteLine(row.Username);
            }
            sw.Close();
            
        }
    }
}
