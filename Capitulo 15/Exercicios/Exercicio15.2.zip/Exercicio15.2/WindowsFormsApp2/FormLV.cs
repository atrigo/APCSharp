﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class FormLV : Form
    {
        public FormLV(Database1DataSet.VeiculoDataTable veiculos)
        {
            InitializeComponent();
            BindingSource source = new BindingSource();
            source.DataSource = veiculos;

            foreach (DataRow v in veiculos.Rows)
            {
                ListViewItem item = new ListViewItem(new[] {
                    v["marca"].ToString(),
                    v["modelo"].ToString(),
                    v["registo"].ToString(),
                    v["matricula"].ToString() });
                listView1.Items.Add(item);
            }
        }
    }
}
