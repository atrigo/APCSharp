﻿namespace WindowsFormsApp2
{


    partial class Database1DataSet
    {
    }
}

namespace WindowsFormsApp2.Database1DataSetTableAdapters {
    
    
    public partial class VeiculoTableAdapter {
    }
}
