﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    public class Veículo
    {
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public DateTime Registo { get; set; }
        public string Matrícula { get; set; }
        public Veículo()// Sem este construtor o bindingNavigator não pode adicionar novos elementos
        {
            Registo = DateTime.Today;// Para que as instâncias da classe não tenham uma data (01/01/0001) impossível de atribuir ao DateTimePicker
        }
        public Veículo(string marca, string modelo, DateTime reg, string mt)
        {
            Marca = marca;
            Modelo = modelo;
            if (reg < new DateTime(1753, 1, 1))// O dateTimePicker não aceita datas anteriores a esta 
                Registo = new DateTime(1753, 1, 1);
            else
                Registo = reg;
            Matrícula = mt;
        }
    }
}
