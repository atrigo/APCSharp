﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class FormMatric : Form
    {
        public string Mat { get; set; }
        public FormMatric()
        {
            InitializeComponent();
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            if (maskedTextBoxMatrícula.MaskCompleted)
            {
                Mat = maskedTextBoxMatrícula.Text;
                Close();
            }
            else
                MessageBox.Show("Matrícula incompleta ou inválida");
        }
    }
}
