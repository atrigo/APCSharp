﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class FormDGV : Form
    {
        private string param;
        private string valor;
        public FormDGV(string param, string valor)
        {
            InitializeComponent();
            this.param = param;
            this.valor = valor;
        }

        private void FormDGV_Load(object sender, EventArgs e)
        {
            switch (param) {
                case "ano":
                    this.veiculoTableAdapter.FillByAno(this.database1DataSet.Veiculo,Convert.ToDecimal(valor));
                    break;
                case "marca":
                    this.veiculoTableAdapter.FillByMarca(this.database1DataSet.Veiculo,valor);
                    break;
                case "matricula":
                    this.veiculoTableAdapter.FillByMatricula(this.database1DataSet.Veiculo,valor);
                    break;
                default:
                    this.veiculoTableAdapter.Fill(this.database1DataSet.Veiculo);
                    break;
            }
        }
    }
}
