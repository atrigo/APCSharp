﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class FormVeiculo : Form
    {
        Database1DataSet.VeiculoDataTable veiculos2 = new Database1DataSet.VeiculoDataTable();
        string matric;
        public FormVeiculo()
        {
            InitializeComponent();
        }

        private void ActivaMenus(bool bloq)
        {
            bindingNavigator1.Enabled = bloq;
            pesquisaToolStripMenuItem.Enabled = bloq;
            ordenaçãoToolStripMenuItem.Enabled = bloq;
            contextMenuStrip1.Enabled = bloq;
        }

        private void GuardaAlteracoesNaBD() {
            this.veiculoBindingSource.EndEdit();
            this.veiculoTableAdapter.Update(this.database1DataSet);
        }
        private bool VeiculoCompleto()
        {
            if( maskedTextBoxMatrícula.MaskCompleted)
            {
                toolStripStatusLabel1.Text = "";
                //Atualiza veiculo na BD
                GuardaAlteracoesNaBD();
                return true;
            }
            else
            {
                toolStripStatusLabel1.Text = "Dados do veículo incompletos";
                return false;
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            if (dateTimePicker1.Value.Year < 1992)
            {          maskedTextBoxMatrícula.Mask = ">LL-00-00";
                matric="LL-00-00";
            }
            else
                if (dateTimePicker1.Value.Year <= 2005)
                {
                    maskedTextBoxMatrícula.Mask = ">00-00-LL";
                    matric="00-00-LL";
                }
                else
                {
                    maskedTextBoxMatrícula.Mask = ">00-LL-00";
                    matric= "00-LL-00";                  
                }
        }

        private void comboBoxMarca_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxMarca.SelectedValue == null)
                comboBoxMarca.SelectedIndex = 0;
            else 
            this.marcaModeloTableAdapter.FillBy(this.database1DataSet.MarcaModelo,
                comboBoxMarca.SelectedValue.ToString());
            //Trocar a propriedade DropDownStyle para DropDownList de modo a evitar que o 
            //utlizador possa introduzir valores que não constam da lista
            ActivaMenus(VeiculoCompleto());
        }

        private void comboBoxModelo_SelectedIndexChanged(object sender, EventArgs e)
        {
            ActivaMenus(VeiculoCompleto());
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            dateTimePicker1.Value = DateTime.Today;
            ActivaMenus(false);
        }

        private void maskedTextBoxMatrícula_KeyUp(object sender, KeyEventArgs e)
        {
            //Sempre que o utilizador digita algo é feita uma validação de completude
            ActivaMenus(VeiculoCompleto());
        }


        private void maskedTextBoxMatrícula_Enter(object sender, EventArgs e)
        {
            //toolTip1.ToolTipTitle = "Formato da matrícula";
            toolTip1.Show(matric, maskedTextBoxMatrícula, 0, -20);
        }

        private void maskedTextBoxMatrícula_Leave(object sender, EventArgs e)
        {
            toolTip1.Hide(maskedTextBoxMatrícula);
        }

        private void listarDataGridViewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormDGV f = new FormDGV("","");
            f.ShowDialog();
            f.Dispose(); // Quando se apresenta uma form usando ShowDialog(), ao fechá-la esta fica no estado hidden, daí a necessidade de usar dispose()
        }

        private void listarListViewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormLV f = new FormLV(veiculos2);
            f.ShowDialog();
            f.Dispose(); // Uma chamada a ShowDialog(), ao contrário de Show(), não tem dispose associado.
        }

        private void marcaToolStripMenuItem_Click(object sender, EventArgs e)//PESQUISA por marca
        {
            FormMarca f = new FormMarca();
            f.ShowDialog();
            int temp = this.veiculoTableAdapter.GetDataByMarca(f.Marca).Count;
            if (temp == 0)
                MessageBox.Show("Não há Veículos da marca selecionada");
            else
            {
                FormDGV g = new FormDGV("marca", f.Marca);
                g.ShowDialog();
                g.Dispose(); // Uma chamada a ShowDialog(), ao contrário de Show(), não tem dispose associado.
            }
            f.Dispose(); // Uma chamada a ShowDialog(), ao contrário de Show(), não tem dispose associado.
        }

        private void anoDeRegistoToolStripMenuItem_Click(object sender, EventArgs e)//PESQUISA por ano de registo
        {
            FormAno f = new FormAno();
            f.ShowDialog();
            int temp = this.veiculoTableAdapter.GetDataByAno(f.Ano).Count;
            if (temp == 0)
                MessageBox.Show("Não há Veículos do ano selecionado");
            else
            {
                FormDGV g = new FormDGV("ano",f.Ano.ToString());
                g.ShowDialog();
                g.Dispose(); // Uma chamada a ShowDialog(), ao contrário de Show(), não tem dispose associado.
            }
            f.Dispose(); // Uma chamada a ShowDialog(), ao contrário de Show(), não tem dispose associado.
        }

        private void matrículaToolStripMenuItem_Click(object sender, EventArgs e)//PESQUISA por matrícula
        {
            FormMatric f = new FormMatric();
            f.ShowDialog();
            int temp = this.veiculoTableAdapter.GetDataByMatricula(f.Mat).Count;
            if (temp == 0)
                MessageBox.Show("Não há Veículos do ano selecionado");
            else
            {
                FormDGV g = new FormDGV("matricula", f.Mat);
                g.ShowDialog();
                g.Dispose(); // Uma chamada a ShowDialog(), ao contrário de Show(), não tem dispose associado.
            }
            f.Dispose(); // Uma chamada a ShowDialog(), ao contrário de Show(), não tem dispose associado.

        }

        private void marcaToolStripMenuItem1_Click(object sender, EventArgs e)//Ordenação por marca
        {
            Database1DataSet.VeiculoDataTable v3 = veiculoTableAdapter.GetData();
            veiculos2.Clear();
            veiculos2.Merge(v3.OrderBy(k => k.Marca).CopyToDataTable());
            listarListViewToolStripMenuItem_Click(sender, e);
        }

        private void dataDeRegistoToolStripMenuItem_Click(object sender, EventArgs e)//Ordenação por data de registo
        {
            Database1DataSet.VeiculoDataTable v3 = veiculoTableAdapter.GetData();
            veiculos2.Clear();
            veiculos2.Merge(v3.OrderBy(k => k.Registo).CopyToDataTable());
            listarListViewToolStripMenuItem_Click(sender, e);
        }

        private void matrículaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Database1DataSet.VeiculoDataTable v3 = veiculoTableAdapter.GetData();
            veiculos2.Clear();
            veiculos2.Merge(v3.OrderBy(k => k.Matricula).CopyToDataTable());
            listarListViewToolStripMenuItem_Click(sender, e);
        }

        private void FormVeiculo_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'database1DataSet.Veiculo'. Você pode movê-la ou removê-la conforme necessário.
            this.veiculoTableAdapter.Fill(this.database1DataSet.Veiculo);
            // TODO: esta linha de código carrega dados na tabela 'database1DataSet.Marca'. Você pode movê-la ou removê-la conforme necessário.
            this.marcaTableAdapter.Fill(this.database1DataSet.Marca);
            // TODO: esta linha de código carrega dados na tabela 'database1DataSet.MarcaModelo'. Você pode movê-la ou removê-la conforme necessário.
            //string marca = ((Database1DataSet.VeiculoDataTable)this.veiculoBindingSource.Current);

            this.marcaModeloTableAdapter.FillBy(this.database1DataSet.MarcaModelo, comboBoxMarca.Text);
            //this.marcaModeloTableAdapter.Fill(this.database1DataSet.MarcaModelo);
        }

        private void veiculoBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            GuardaAlteracoesNaBD();
        }
    }
}
