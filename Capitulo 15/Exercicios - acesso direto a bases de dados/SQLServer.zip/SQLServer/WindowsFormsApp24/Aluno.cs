﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp24
{
    class Aluno
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Curso { get; set; }

        public string Email { get; set; }

        public Aluno() {
        }

        public Aluno(int id, string nome, string curso, string email)
        {
            Id = id;
            Nome = nome;
            Curso = curso;
            Email = email;
        }
    }
}
