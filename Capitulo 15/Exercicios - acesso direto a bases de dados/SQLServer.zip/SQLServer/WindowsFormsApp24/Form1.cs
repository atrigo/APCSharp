﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp24
{
    public partial class Form1 : Form
    {
        List<Aluno> a;
        List<String> curso;
        public Form1()
        {
            InitializeComponent();
        }

        private void LigaLista() {
            bindingSource1.DataSource = a;
            dataGridView1.DataSource = bindingSource1;
        }

        private void CarregaCursoDaBD()
        {

            //Cria uma nova lista
            curso = new List<String>();

            string ConnectionString1 = "Data Source=localhost;Initial Catalog=Escola;Integrated Security=True";
            using (var connection = new SqlConnection(ConnectionString1))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT DISTINCT CURSO FROM ALUNO ORDER BY CURSO";
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            curso.Add(reader["Curso"].ToString());
                        }
                    }
                }
            }
            bindingSource2.ResetBindings(true);
            bindingSource2.DataSource = curso;
            comboBox1.DataSource = bindingSource2;
        }

        private void CarregaBD() {

            //Cria uma nova lista
            a = new List<Aluno>();

            string ConnectionString1 = "Data Source=localhost;Initial Catalog=Escola;Integrated Security=True";
            using (var connection = new SqlConnection(ConnectionString1))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT * FROM ALUNO";
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Aluno aluno = new Aluno(
                                Convert.ToInt32(reader["Id"].ToString()),
                                reader["Nome"].ToString(),
                                reader["Curso"].ToString(),
                                reader["Email"].ToString());
                            a.Add(aluno);
                        }
                    }
                }
            }
            bindingSource1.ResetBindings(true);
            bindingSource1.DataSource = null;
            dataGridView1.DataSource = null;

            //dataGridView1.AutoGenerateColumns = true;
            bindingSource1.DataSource = a;
            dataGridView1.DataSource = bindingSource1;

        }
        private void button1_Click(object sender, EventArgs e)
        {
            CarregaBD();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string ConnectionString1 = "Data Source=localhost;Initial Catalog=Escola;Integrated Security=True";
            using (var connection = new SqlConnection(ConnectionString1))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "DELETE FROM ALUNO WHERE Id = @id";
                    command.Parameters.AddWithValue("@id", numericUpDown1.Value);
                    command.ExecuteNonQuery();
                }
            }
            CarregaBD();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string ConnectionString1 = "Data Source=localhost;Initial Catalog=Escola;Integrated Security=True";
            using (var connection = new SqlConnection(ConnectionString1))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "INSERT INTO ALUNO " +
                        "(nome,curso,email) values(@nome, @curso, @email)";
                    command.Parameters.AddWithValue("@nome", textBox1.Text.ToString());
                    command.Parameters.AddWithValue("@curso", textBox2.Text.ToString());
                    command.Parameters.AddWithValue("@email", textBox3.Text.ToString());
                    command.ExecuteNonQuery();
                }
            }
            CarregaBD();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CarregaCursoDaBD();
            LigaLista();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            CarregaBDByCurso(comboBox1.SelectedItem.ToString());
        }


        private void CarregaBDByCurso(string cursoNome)
        {

            //Cria uma nova lista
            a = new List<Aluno>();

            string ConnectionString1 = "Data Source=localhost;Initial Catalog=Escola;Integrated Security=True";
            using (var connection = new SqlConnection(ConnectionString1))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT * FROM ALUNO WHERE CURSO = @curso";

                    command.Parameters.AddWithValue("@curso", cursoNome);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Aluno aluno = new Aluno(
                                Convert.ToInt32(reader["Id"].ToString()),
                                reader["Nome"].ToString(),
                                reader["Curso"].ToString(),
                                reader["Email"].ToString());
                            a.Add(aluno);
                        }
                    }
                }
            }
            bindingSource1.ResetBindings(true);
            bindingSource1.DataSource = null;
            dataGridView1.DataSource = null;

            //dataGridView1.AutoGenerateColumns = true;
            bindingSource1.DataSource = a;
            dataGridView1.DataSource = bindingSource1;

        }
    }
}
