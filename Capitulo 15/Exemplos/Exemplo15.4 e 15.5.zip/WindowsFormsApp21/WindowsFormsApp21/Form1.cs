﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp21
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bd1DataSet.Pessoa' table. You can move, or remove it, as needed.
            this.pessoaTableAdapter.Fill(this.bd1DataSet.Pessoa);

        }

        private void buttonPrimeiro_Click(object sender, EventArgs e)
        {
            
        }

        private void buttonAnterior_Click(object sender, EventArgs e)
        {
            if (bindingSource1.Position > 0)
            {
                bindingSource1.MovePrevious();
                //Gravar alteracoes
                bindingSource1.EndEdit();
                pessoaTableAdapter.Update(bd1DataSet);
            }
            else
                MessageBox.Show("Ja esta no primeiro registo!");
        }

        private void buttonProximo_Click(object sender, EventArgs e)
        {

            if (bindingSource1.Position < bindingSource1.Count -1)
                bindingSource1.MoveNext();
            else
                MessageBox.Show("Ja esta no ultimo registo!");
        }

        private void Adicionar_Click(object sender, EventArgs e)
        {
            bindingSource1.AddNew();
            buttonGuardar.Visible = true;
            buttonPrimeiro.Enabled = false;
            buttonAnterior.Enabled = false;
            buttonProximo.Enabled = false;
            buttonUltimo.Enabled = false;
            buttonAdicionar.Enabled = false;
            buttonEliminar.Enabled = false;
            
            textBoxNome.Clear();
            numericUpDownIdade.ResetText();

        }

        private void buttonGuardar_Click(object sender, EventArgs e)
        {
            bindingSource1.EndEdit();
            pessoaTableAdapter.Update(bd1DataSet);

            buttonGuardar.Visible = false;
            buttonPrimeiro.Enabled = true;
            buttonAnterior.Enabled = true;
            buttonProximo.Enabled = true;
            buttonUltimo.Enabled = true;
            buttonAdicionar.Enabled = true;
            buttonEliminar.Enabled = true;
        }

        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Tem a certeza que quer eliminar esta pessoa?",
                "Eliminar pessoa",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                bindingSource1.RemoveCurrent();
                pessoaTableAdapter.Update(bd1DataSet);
            }
        }
    }
}
